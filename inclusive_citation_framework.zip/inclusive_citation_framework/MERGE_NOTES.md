# Merge notes

How `inclusive_citation_framework` (Flask, APA/MLA/IEEE) and `inclusive_citation_project`
(Streamlit, BibTeX extension) became one project.

## Decision: Flask is the base

| Reason | Detail |
| --- | --- |
| Matches the submitted report | The report names Python + Flask + HTML/CSS/JS. |
| Lighter | Flask only, versus Streamlit + pandas (pandas was used just to show a table). |
| More control | Type-dependent form fields, copy-with-italics, downloads, CSRF and CSP are straightforward. |
| Fills the report's own *Future Scope* | BibTeX export, transliteration, and improved validation were listed as future work; the Streamlit project had already built them. |

## What came from where (no overlap)

| Feature | From | In the merged project |
| --- | --- | --- |
| APA / MLA / IEEE drafts | Flask project | Kept, rewritten per source type; italics; `n.d.`; no-author handling |
| Book, journal, web | Flask project | Kept |
| Government report, patent | Streamlit project | Kept, and now also formatted in APA / MLA / IEEE |
| Translator, edition, DOI, access date | Flask project | Kept; added *original publication year* |
| Original-language title, language | Both | **One** set of fields (see mapping below) |
| Transliteration | Streamlit project | Kept; can optionally be the title shown in references |
| Extended BibTeX (`originaltitle`, `translatedtitle`, `transliteration`, `country`) | Streamlit project | Kept for all five source types |
| Citation key generator | Streamlit project | Kept, improved (see fixes) |
| Session library, `.bib` download | Streamlit project | Kept; added remove, duplicate detection, caps |
| Validation | Both | Merged into one validator (errors block, warnings advise) |
| Warnings instead of silent output | Flask project | Kept as the core philosophy |
| Copy buttons, sample loader, responsive UI | Flask project | Kept; copy now also keeps italics |
| Fictional demonstration data | Streamlit project | Kept and extended to all five types |
| Viva questions | Streamlit project README | Moved to `docs/VIVA_QA.md` and updated |

### Field mapping (so old data can be translated)

| Flask project | Streamlit project | Merged field |
| --- | --- | --- |
| `author` | `author_or_inventor` | `author` |
| `title` | `translated_title` | `title` |
| `original_title` | `original_title` | `original_title` |
| – | `transliteration` | `transliteration` |
| `language` | `language` | `language` |
| `publisher` | `department_or_office` | `publisher` (label changes with source type) |
| `year` | `year` | `year` |
| `doi`, `url`, `access_date`, `edition`, `journal`, `volume`, `issue`, `pages`, `translator` | – | same names |
| – | `identifier` | `identifier` (report no. / patent no.) |
| – | `country` | `country` |
| – | – | **new:** `original_year`, `title_display` |

## Bugs and weaknesses fixed

**Flask project**
- APA web citation printed the URL twice (`… URL Retrieved …, from URL`).
- IEEE numbers were hard-coded as `[1]` everywhere (now numbered in lists).
- The “Preferred style for review” dropdown did nothing (removed; all styles are always shown).
- A DOI-without-URL warning made no sense (removed); the “prototype limitation” text was appended
  to the warnings list on every run (now a permanent footer note).
- Translation info was a non-standard “Original title: …; translated by …; original language: …” note.
  It is now handled the way the styles do it: bracketed translation for non-English originals,
  translator credit + original publication year for translated editions.
- Fields typed for one source type could leak into another after switching type (now ignored).
- Invalid input never blocked output: a malformed year or URL still produced a citation. Only a missing title was an error.
- The Tagore sample used a single year (1910) for what is really two dates. It now uses separate fields: original publication 1910, English edition 1913. Sample details are illustrative, so please verify them before quoting them anywhere.

**Streamlit project**
- README advertised a Home page, a Research Background page, a one-click sample loader and CSV export that
  were **not in `app.py`** (`sample_data.py` and `export_citations_to_csv` were never used). They are now real
  (sample loader, CSV export, About page).
- TeX escaping skipped backslashes and braces, so hostile or unusual input could break the `.bib`.
- Citation keys for Devanagari authors fell back to a word from the *title*; now the Latin part of the
  author is used (`patil2023maharashtra`).
- Duplicate detection compared keys only and keys could collide silently; keys are now unique per file.
- Form labels that depend on source type did not update inside `st.form`; they now update live.
- CSV export had no protection against spreadsheet formula injection.

## Deliberately dropped

| Dropped | Why |
| --- | --- |
| Streamlit and pandas | Replaced by Flask; no feature depended on them |
| `.kilo/` folder | Editor/agent configuration, not part of the project |
| `.venv/`, `__pycache__/` | Machine-specific; recreate with `requirements.txt` |
| `patentnumber` BibTeX field and `institution` on patents | Duplicated `number` and `holder` (the standard BibLaTeX fields) |
| Separate “readable citation” format | Same purpose as the APA/MLA/IEEE drafts, which now carry the original title, translation and transliteration |
| Free-text “Preferred style” | Unused |

## Things worth knowing

- **Your submitted report** (`Reports/RM Project Report 1.docx`) describes the *earlier* Flask prototype
  (three source types, no export). The merged project is a superset, so the report remains true, but if you
  want it to match, update the Implementation section (five source types, BibTeX/CSV export, transliteration,
  session library) and move those items out of *Future Scope*.
- Names are still used exactly as typed; automatic name parsing was left out on purpose (unsafe for
  multilingual names).
- The 69 tests verify behaviour (including a real-browser pass for the UI), not conformance to the
  official style manuals.
