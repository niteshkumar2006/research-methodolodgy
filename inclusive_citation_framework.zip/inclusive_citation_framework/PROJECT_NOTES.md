# Project notes for later report writing

## Proposed problem
Researchers and students may use scholarly sources in non-English languages or translated editions. Citation records can omit the original title, translator, or language context, and a single generic form may not capture all details needed by different referencing styles.

## Proposed aim
Design and prototype a citation-support framework that captures language and translation metadata and helps users prepare and review references in APA, MLA, and IEEE styles.

## Draft objectives
1. Identify citation fields relevant to non-English and translated sources.
2. Compare official guidance for APA, MLA, and IEEE for selected source types.
3. Implement a prototype that generates draft references from structured metadata.
4. Add checks that flag potentially missing or inconsistent metadata.
5. Evaluate output against a manually curated set of examples and document limitations.

## Research questions
1. Which metadata fields are needed to represent non-English and translated academic sources transparently?
2. How do APA, MLA, and IEEE differ for selected source types and translation scenarios?
3. How accurately does the prototype reproduce references for a defined test set?
4. Which usability issues remain for multilingual users?

## Important next steps
- Conduct a literature review and cite official, current APA/MLA/IEEE guidance.
- Build a test set covering books, journal articles, and web pages, including translated and untranslated cases.
- Define a scoring rubric before evaluation.
- Do not claim accuracy percentages until the system is tested.
- Keep this note as a planning draft, not as a completed research paper.
