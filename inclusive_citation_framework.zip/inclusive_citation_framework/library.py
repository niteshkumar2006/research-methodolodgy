"""library.py
----------
Per-browser-session citation library (the Flask equivalent of Streamlit's
``st.session_state`` library in the earlier project).

Records live in server memory, keyed by a random session id stored in the
signed session cookie. They disappear when the server restarts - export a
.bib / .csv / .txt file to keep them. This keeps the prototype free of a
database, on purpose.
"""
from __future__ import annotations

import threading
import uuid
from collections import OrderedDict

from citation_engine import FIELDS, normalize

MAX_SESSIONS = 500
MAX_RECORDS = 200


def _fingerprint(record: dict) -> tuple:
    r = normalize(record)
    return (r.source_type, r.author.casefold(), r.year, r.title.casefold(),
            r.original_title.casefold(), r.identifier.casefold(),
            r.doi.casefold(), r.url.casefold())


class LibraryStore:
    def __init__(self, max_sessions: int = MAX_SESSIONS, max_records: int = MAX_RECORDS):
        self._data: "OrderedDict[str, list[dict]]" = OrderedDict()
        self._lock = threading.Lock()
        self.max_sessions = max_sessions
        self.max_records = max_records

    def _bucket(self, sid: str) -> list[dict]:
        if sid not in self._data:
            self._data[sid] = []
            while len(self._data) > self.max_sessions:
                self._data.popitem(last=False)  # drop the least recently used
        self._data.move_to_end(sid)
        return self._data[sid]

    def records(self, sid: str) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._bucket(sid)]

    def add(self, sid: str, record: dict) -> tuple[str, dict | None]:
        """Return ('added' | 'duplicate' | 'full', stored_record_or_None)."""
        clean_rec = {f: getattr(normalize(record), f) for f in FIELDS}
        with self._lock:
            bucket = self._bucket(sid)
            fp = _fingerprint(clean_rec)
            if any(_fingerprint(r) == fp for r in bucket):
                return "duplicate", None
            if len(bucket) >= self.max_records:
                return "full", None
            clean_rec["id"] = uuid.uuid4().hex[:10]
            bucket.append(clean_rec)
            return "added", dict(clean_rec)

    def remove(self, sid: str, record_id: str) -> bool:
        with self._lock:
            bucket = self._bucket(sid)
            for i, rec in enumerate(bucket):
                if rec["id"] == record_id:
                    del bucket[i]
                    return True
            return False

    def clear(self, sid: str) -> int:
        with self._lock:
            bucket = self._bucket(sid)
            n = len(bucket)
            bucket.clear()
            return n
