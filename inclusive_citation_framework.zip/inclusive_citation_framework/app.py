"""app.py
------
Flask web application for the Inclusive Citation Framework.

Pages
  /                      generate APA / MLA / IEEE drafts + extended BibTeX
  /library               session library (view, remove, clear, export)
  /library/export/<fmt>  bib | csv | txt
  /about                 framework, BibTeX schema, limitations

Run:  python app.py   ->  http://127.0.0.1:5000
"""
from __future__ import annotations

import hmac
import os
import re
import secrets
import uuid
from pathlib import Path

from flask import (Flask, Response, abort, flash, redirect, render_template,
                   request, session, url_for)

from bibtex_export import (export_bib, export_csv, export_reference_list,
                           generate_bibtex, generate_citation_key,
                           type_counts, unique_keys)
from citation_engine import (FIELDS, LANGUAGES, MAX_FIELD_LEN, SOURCE_TYPES,
                             STYLE_NAMES, TYPE_EXTRA_FIELDS, TYPE_LABELS,
                             COMMON_FIELDS, generate_citation, normalize,
                             to_html, to_plain)
from library import LibraryStore
from sample_data import SAMPLES
from validator import validate_source

BASE_DIR = Path(__file__).resolve().parent


def _load_secret_key() -> str:
    """SECRET_KEY env var, else a key persisted in .secret_key, else random."""
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = BASE_DIR / ".secret_key"
    try:
        if path.exists():
            value = path.read_text().strip()
            if value:
                return value
        value = secrets.token_hex(32)
        path.write_text(value)
        return value
    except OSError:  # read-only file system etc.
        return secrets.token_hex(32)


app = Flask(__name__)
app.config.update(
    SECRET_KEY=_load_secret_key(),
    MAX_CONTENT_LENGTH=64 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
library = LibraryStore()


# --------------------------------------------------------------------------
# Session, CSRF and security headers
# --------------------------------------------------------------------------
def csrf_token() -> str:
    token = session.get("_csrf")
    if not token:
        token = session["_csrf"] = secrets.token_urlsafe(32)
    return token


def session_id() -> str:
    if "sid" not in session:
        session["sid"] = uuid.uuid4().hex
    return session["sid"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def _csrf_protect():
    if request.method == "POST":
        expected = session.get("_csrf", "")
        sent = request.form.get("csrf_token", "")
        if not expected or not hmac.compare_digest(sent.encode(), expected.encode()):
            abort(400, description="Your session expired or the form was "
                                   "invalid. Please reload the page and try again.")


@app.after_request
def _security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data:; object-src 'none'; "
        "base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
    return resp


@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(413)
def _http_error(err):
    return render_template("error.html", code=err.code, name=err.name,
                           message=err.description), err.code


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def blank_form() -> dict:
    data = {f: "" for f in FIELDS}
    data["source_type"] = "book"
    data["title_display"] = "native"
    return data


def read_form(form) -> dict:
    data = blank_form()
    for field in FIELDS:
        data[field] = (form.get(field) or "").strip()[:MAX_FIELD_LEN]
    if data["source_type"] not in TYPE_LABELS:
        data["source_type"] = "book"
    if data["title_display"] not in ("native", "translit"):
        data["title_display"] = "native"
    return data


def build_results(data: dict) -> list[dict]:
    results = []
    for style in STYLE_NAMES:
        markup = generate_citation(data, style)
        prefix = "[1] " if style == "IEEE" else ""
        results.append({
            "style": style,
            "text": prefix + to_plain(markup),
            "html": to_html(prefix + markup),
        })
    return results


def common_context() -> dict:
    return {
        "source_types": SOURCE_TYPES,
        "languages": LANGUAGES,
        "styles": STYLE_NAMES,
        "field_config": {
            "common": sorted(COMMON_FIELDS),
            "extra": {k: sorted(v) for k, v in TYPE_EXTRA_FIELDS.items()},
        },
        "samples": SAMPLES,
        "field_names": FIELDS,
    }


def render_generator(data, errors=(), warnings=(), results=None, **extra):
    ctx = common_context()
    if results:
        ctx["bibtex"] = generate_bibtex(data)
        ctx["citation_key"] = generate_citation_key(data)
    return render_template("index.html", data=data, errors=list(errors),
                           warnings=list(warnings), results=results,
                           **ctx, **extra)


# --------------------------------------------------------------------------
# Generator
# --------------------------------------------------------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_generator(blank_form())
    data = read_form(request.form)
    errors, warnings = validate_source(data)
    results = None if errors else build_results(data)
    return render_generator(data, errors, warnings, results)


@app.post("/download/bib")
def download_single_bib():
    data = read_form(request.form)
    errors, _ = validate_source(data)
    if errors:
        return render_generator(data, errors), 400
    key = generate_citation_key(data)
    body = export_bib([data])
    return _file_response(body, f"{key}.bib")


# --------------------------------------------------------------------------
# Library
# --------------------------------------------------------------------------
@app.post("/library/add")
def library_add():
    data = read_form(request.form)
    errors, warnings = validate_source(data)
    if errors:
        return render_generator(data, errors, warnings), 400
    status, _record = library.add(session_id(), data)
    if status == "added":
        flash("Saved to your library.", "success")
    elif status == "duplicate":
        flash("This source is already in your library.", "warning")
    else:
        flash("Your library is full (200 records). Export it and clear it "
              "before adding more.", "error")
    return redirect(url_for("library_page"))


@app.get("/library")
def library_page():
    records = library.records(session_id())
    keys = unique_keys(records)
    rows = []
    for index, (rec, key) in enumerate(zip(records, keys), start=1):
        r = normalize(rec)
        rows.append({
            "id": rec["id"],
            "n": index,
            "key": key,
            "type": TYPE_LABELS[r.source_type],
            "title": r.title or r.original_title,
            "original_title": r.original_title if r.title else "",
            "language": r.language,
            "year": r.year,
            "refs": [{"style": s,
                      "html": to_html(("[%d] " % index if s == "IEEE" else "")
                                      + generate_citation(rec, s))}
                     for s in STYLE_NAMES],
            "bibtex": generate_bibtex(rec, key),
        })
    counts = type_counts(records)
    return render_template(
        "library.html", rows=rows, total=len(rows), styles=STYLE_NAMES,
        counts=[(label, counts[value]) for value, label in SOURCE_TYPES])


@app.post("/library/remove/<record_id>")
def library_remove(record_id):
    if library.remove(session_id(), record_id):
        flash("Record removed.", "success")
    else:
        flash("That record was not found.", "warning")
    return redirect(url_for("library_page"))


@app.post("/library/clear")
def library_clear():
    if request.form.get("confirm") != "yes":
        flash("Please tick the confirmation box to clear the library.", "warning")
    else:
        n = library.clear(session_id())
        flash(f"Cleared {n} record(s).", "success")
    return redirect(url_for("library_page"))


def _file_response(body: str, filename: str, *, bom: bool = False) -> Response:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", filename)
    data = ("\ufeff" + body if bom else body).encode("utf-8")
    return Response(data, content_type="text/plain; charset=utf-8" if not filename.endswith(".csv")
                    else "text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{safe}"'})


@app.get("/library/export/<fmt>")
def library_export(fmt):
    records = library.records(session_id())
    if not records:
        flash("Your library is empty - add a citation first.", "warning")
        return redirect(url_for("library_page"))
    if fmt == "bib":
        return _file_response(export_bib(records), "multilingual_citations.bib")
    if fmt == "csv":  # BOM so Excel shows Indic scripts correctly
        return _file_response(export_csv(records), "multilingual_citations.csv", bom=True)
    if fmt == "txt":
        style = request.args.get("style", "APA")
        if style not in STYLE_NAMES:
            abort(400, description="Unknown citation style.")
        return _file_response(export_reference_list(records, style),
                              f"references_{style.lower()}.txt")
    abort(404, description="Unknown export format.")


# --------------------------------------------------------------------------
# About
# --------------------------------------------------------------------------
@app.get("/about")
def about():
    return render_template("about.html")


if __name__ == "__main__":
    # Debug mode exposes an interactive debugger, so it is opt-in only.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")),
            debug=os.environ.get("FLASK_DEBUG") == "1")
