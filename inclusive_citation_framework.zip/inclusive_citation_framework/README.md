# Inclusive Citation Framework

**Research Methodology project: a citation-support framework for non-English and translated academic sources.**

A small Flask web application that captures language and translation metadata and drafts
**APA, MLA and IEEE** references plus **extended BibTeX / BibLaTeX** for books, journal articles,
web pages, government reports and patents, while keeping original scripts (Devanagari, Bengali,
Tamil, …) intact.

> This project is the merge of two earlier prototypes (a Flask APA/MLA/IEEE generator and a
> Streamlit BibTeX-extension tool). See [`MERGE_NOTES.md`](MERGE_NOTES.md) for what was kept,
> fixed and dropped.

---

## Features

| Area | What it does |
| --- | --- |
| **Source types** | Book · Journal article · Web page · Government / institutional report · Patent |
| **Styles** | Draft APA, MLA and IEEE references side by side, with italics preserved when copied into Word |
| **Multilingual metadata** | Language, original-language title (native script), optional Latin transliteration, translator, original publication year |
| **Two translation scenarios** | *Citing a non-English original* → original title + `[English translation]` (+ “(in Language)” in IEEE). *Citing a translated edition* → translated title + translator + original publication year |
| **Transliteration option** | Choose whether references print the native script or the transliteration; BibTeX always keeps the native script |
| **Extended BibTeX** | `@book`, `@article`, `@online`, `@techreport`, `@patent` with extension fields `originaltitle`, `translatedtitle`, `transliteration`, `country`; proper TeX escaping; readable unique citation keys (e.g. `patil2023maharashtra`) |
| **Validation** | Blocks only meaningless output (no title, bad year/URL, patent without number); otherwise gives review warnings (missing translator details, non-Latin title without transliteration, …) |
| **Session library** | Save records, view all three styles + BibTeX, remove, clear (with confirmation), duplicate detection |
| **Exports** | `.bib` (UTF-8), `.csv` (UTF-8 with BOM so Excel shows Indic scripts; spreadsheet-formula safe), and plain-text reference lists in APA / MLA / IEEE |
| **Samples** | One-click sample for each source type (fictional data, except the Gitanjali example) |
| **Security basics** | CSRF tokens, strict Content-Security-Policy, escaped output, input length limits, debug mode off by default |

---

## Run it

Requires **Python 3.10+**. The only dependency is Flask.

### Windows (PowerShell / VS Code)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation, run Python from the venv directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000**.

Optional environment variables: `PORT` (default 5000), `FLASK_DEBUG=1` (auto-reload; development only),
`SECRET_KEY` (otherwise a key is generated once and stored in `.secret_key`).

### Run the tests

```bash
python -m unittest discover -s tests -t . -v
```

---

## Suggested demo (for presentation / viva)

1. Open **Generator**, pick **Load a sample → Translated book – Gitanjali**, press **Generate citations**.
   Show the APA “(Original work published 1910)” and translator credit.
2. Load **Non-English journal article – Hindi**. Note the bracketed English translation and IEEE “(in Hindi)”.
   Switch **Title shown in references** to *Transliteration* and regenerate.
3. Load **Government report – Marathi**. Show the BibTeX block: native-script `title`/`originaltitle`,
   `translatedtitle`, `transliteration`, `institution`, `number`.
4. Clear the transliteration or the original title and regenerate to show the review warnings.
5. **Save to library** a few records → **Library** → export `.bib`, `.csv` and an IEEE list.

---

## Project structure

```text
inclusive_citation_framework/
├── app.py                # Flask routes, CSRF, security headers, downloads
├── citation_engine.py    # APA / MLA / IEEE rules for the 5 source types
├── bibtex_export.py      # Extended BibTeX, citation keys, CSV and text exports
├── validator.py          # Errors (blocking) and warnings (advisory)
├── library.py            # Per-session in-memory library
├── sample_data.py        # Demonstration records
├── templates/            # base, index (generator), library, about, error
├── static/               # style.css, app.js
├── tests/                # 69 unit / integration tests
├── docs/VIVA_QA.md       # Viva questions and answers
├── Reports/              # Submitted report (describes the earlier Flask prototype)
├── MERGE_NOTES.md        # How the two projects were merged
├── PROJECT_NOTES.md      # Original planning notes
└── requirements.txt
```

---

## Proposed BibTeX extension

| Field | Status | Purpose |
| --- | --- | --- |
| `title` | Standard | Title used in the reference, in `{{…}}` to protect script and capitalisation |
| `originaltitle` | **Extension** | Original-language title, native script (UTF-8) |
| `translatedtitle` | **Extension** | English translation of a non-English title, kept beside the original |
| `transliteration` | **Extension** | Latin-script reading of the original title |
| `country` | **Extension** | Country that issued the report or patent |
| `translator`, `origdate`, `language` | Standard (BibLaTeX) | Translation and language metadata |
| `institution` / `holder` / `number` | Standard | Issuing department, patent holder/office, report or patent number |

Classic BibTeX ignores fields its style does not know, so the extension never causes errors; the extra
fields are printed only when a BibLaTeX data model or custom style asks for them. `@online` and `@patent`
are BibLaTeX entry types (use `@misc` with classic BibTeX). Compile with XeLaTeX or LuaLaTeX and biber for
full Unicode support.

---

## Limitations and research honesty

This is an **educational prototype, not a certified citation generator**.

- Output is a *draft*. Report and patent patterns are adaptations of each style’s general rules, not an
  exhaustive implementation of the manuals. Verify every reference against current official guidance.
- Author names are used **exactly as entered**; the engine does not parse name order, initials or
  multiple-author rules. For BibTeX, separate several authors with “and”.
- Metadata is not verified against catalogues, DOI registries or patent databases.
- Titles are not translated or transliterated automatically.
- The library lives in server memory and is lost on restart (export to keep it). It is meant for a single
  local user, not as a multi-user deployment.
- No accuracy figures are claimed: the test-suite checks that the code behaves as designed, not that the
  output matches every official rule.

## Research evaluation ideas

- Build a documented test set of real multilingual sources (books, articles, web pages, reports, patents).
- Define a scoring rubric *before* evaluating; have a human compare output with the official guidance.
- Measure field completeness, formatting agreement and how often translation details are missing.
- Report sample size, rubric and observed results transparently, including failures.

## Future scope

Metadata look-up (Crossref, OpenAlex, patent APIs) · automatic transliteration of Indic scripts ·
author-name parsing per style · Chicago / Harvard · RIS and CSL-JSON export · a BibLaTeX style package
that prints the dual-title format automatically.
