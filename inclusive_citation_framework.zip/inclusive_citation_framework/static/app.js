/* Inclusive Citation Framework - client-side helpers (no inline scripts: CSP) */
(function () {
  "use strict";
  var configEl = document.getElementById("app-config");
  var config = configEl ? JSON.parse(configEl.textContent) : null;

  /* Field labels that change with the source type */
  var LABELS = {
    book:    { author: "Author / creator", publisher: "Publisher" },
    journal: { author: "Author / creator", publisher: "Publisher (optional)" },
    web:     { author: "Author / organization (leave blank if none)", publisher: "Website / publisher" },
    report:  { author: "Author / issuing agency", publisher: "Issuing department / ministry", identifier: "Report / order / gazette number" },
    patent:  { author: "Inventor(s)", publisher: "Patent office / granting authority", identifier: "Patent number" }
  };

  /* ---- show only the fields that apply to the chosen source type ---- */
  function applyType() {
    if (!config) return;
    var typeEl = document.getElementById("source_type");
    if (!typeEl) return;
    var type = typeEl.value;
    var allowed = {};
    config.fields.common.concat(config.fields.extra[type] || []).forEach(function (f) { allowed[f] = true; });
    document.querySelectorAll(".field[data-field]").forEach(function (el) {
      el.hidden = !allowed[el.getAttribute("data-field")];
    });
    var labels = LABELS[type] || {};
    document.querySelectorAll("[data-label]").forEach(function (el) {
      var key = el.getAttribute("data-label");
      if (!el.hasAttribute("data-default")) el.setAttribute("data-default", el.textContent);
      el.textContent = labels[key] || el.getAttribute("data-default");
    });
  }

  /* ---- sample loader ---- */
  function loadSample(index) {
    var sample = config.samples[index];
    if (!sample) return;
    config.fieldNames.forEach(function (name) {
      var el = document.getElementById(name);
      if (!el) return;
      var value = sample.data[name];
      el.value = value === undefined ? (name === "title_display" ? "native" : "") : value;
    });
    applyType();
  }

  /* ---- copy to clipboard (plain text + rich text so Word keeps italics) ---- */
  function fallbackCopy(el) {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    return ok;
  }

  function copyFrom(button) {
    var el = document.getElementById(button.getAttribute("data-copy"));
    if (!el) return;
    var text = el.innerText.trim();
    var rich = button.getAttribute("data-rich") === "1" && window.ClipboardItem;
    var done = function (ok) {
      var original = button.getAttribute("data-label-original") || button.textContent;
      button.setAttribute("data-label-original", original);
      button.textContent = ok ? "Copied!" : "Select text & copy";
      setTimeout(function () { button.textContent = original; }, 1500);
    };
    var attempt;
    if (rich && navigator.clipboard && navigator.clipboard.write) {
      attempt = navigator.clipboard.write([new ClipboardItem({
        "text/plain": new Blob([text], { type: "text/plain" }),
        "text/html": new Blob([el.innerHTML], { type: "text/html" })
      })]);
    } else if (navigator.clipboard && navigator.clipboard.writeText) {
      attempt = navigator.clipboard.writeText(text);
    } else {
      done(fallbackCopy(el));
      return;
    }
    attempt.then(function () { done(true); }, function () { done(fallbackCopy(el)); });
  }

  document.addEventListener("DOMContentLoaded", function () {
    var typeEl = document.getElementById("source_type");
    if (typeEl) typeEl.addEventListener("change", applyType);
    applyType();

    var sampleEl = document.getElementById("sample");
    if (sampleEl) sampleEl.addEventListener("change", function () {
      if (sampleEl.value !== "") loadSample(parseInt(sampleEl.value, 10));
    });

    document.querySelectorAll("[data-copy]").forEach(function (btn) {
      btn.addEventListener("click", function () { copyFrom(btn); });
    });

    var results = document.getElementById("results");
    if (results && results.scrollIntoView) results.scrollIntoView({ behavior: "smooth", block: "start" });
  });
})();
