"""sample_data.py
--------------
Demonstration records for the "Load sample" menu and the test-suite.

DISCLAIMER: apart from the Gitanjali example (a real, well-known work whose
details should still be verified), every record is FICTIONAL demonstration
data. They do not describe real publications or granted patents.
"""

SAMPLES = [
    {
        "label": "Translated book - Gitanjali (Bengali → English)",
        "data": {
            "source_type": "book",
            "author": "Tagore, Rabindranath",
            "year": "1913",
            "title": "Gitanjali (Song Offerings)",
            "original_title": "গীতাঞ্জলি",
            "transliteration": "Gitanjali",
            "language": "Bengali",
            "translator": "Rabindranath Tagore",
            "original_year": "1910",
            "publisher": "Macmillan",
        },
    },
    {
        "label": "Non-English journal article - Hindi (fictional)",
        "data": {
            "source_type": "journal",
            "author": "Sharma, Ananya",
            "year": "2022",
            "title": "The Role of Digital Tools in Rural Education",
            "original_title": "ग्रामीण शिक्षा में डिजिटल साधनों की भूमिका",
            "transliteration": "Gramin shiksha mein digital sadhanon ki bhumika",
            "language": "Hindi",
            "journal": "Shiksha Anusandhan Patrika",
            "volume": "14",
            "issue": "2",
            "pages": "31–48",
        },
    },
    {
        "label": "Web page - Tamil (fictional)",
        "data": {
            "source_type": "web",
            "author": "",
            "year": "2024",
            "title": "Guidelines for Community Seed Banks",
            "original_title": "சமூக விதை வங்கிகளுக்கான வழிகாட்டுதல்கள்",
            "language": "Tamil",
            "publisher": "Example Agricultural Cooperative",
            "url": "https://example.org/ta/seed-bank-guidelines",
            "access_date": "30 October 2026",
        },
    },
    {
        "label": "Government report - Marathi (fictional)",
        "data": {
            "source_type": "report",
            "author": "डॉ. राजेश व्ही. पाटील (Dr. Rajesh V. Patil)",
            "year": "2023",
            "title": "Maharashtra State Water Conservation and Drought Management Policy Report",
            "original_title": "महाराष्ट्र राज्य जल संवर्धन आणि दुष्काळ व्यवस्थापन धोरण अहवाल",
            "transliteration": "Maharashtra Rajya Jal Samvardhan Ani Dushkal Vyavasthapan Dhoran Ahwal",
            "language": "Marathi",
            "publisher": "जलसंधारण विभाग, महाराष्ट्र शासन (Department of Water Conservation, Government of Maharashtra)",
            "country": "India",
            "identifier": "WRD-MH-2023-REP-04",
            "url": "https://example.gov.in/reports/WRD-MH-2023-REP-04.pdf",
        },
    },
    {
        "label": "Patent - Marathi (fictional)",
        "data": {
            "source_type": "patent",
            "author": "आनंद कुमार शर्मा आणि सुनीता देशमुख (Anand Kumar Sharma and Sunita Deshmukh)",
            "year": "2022",
            "title": "Solar-Powered Automated Grain Drying and Storage Apparatus",
            "original_title": "सौर ऊर्जा संचलित स्वयंचलित धान्य सुकवणी आणि साठवणूक यंत्र",
            "transliteration": "Saur Oorja Sanchalit Swayanchalit Dhanya Sukavani Ani Sathvanuk Yantra",
            "language": "Marathi",
            "publisher": "भारतीय पेटंट कार्यालय (Indian Patent Office)",
            "country": "India",
            "identifier": "IN-2022-41058291-A",
            "url": "https://example.gov.in/patents/IN-2022-41058291-A",
        },
    },
]
