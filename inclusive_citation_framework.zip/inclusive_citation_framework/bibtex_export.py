"""bibtex_export.py
------------------
Extended BibTeX / BibLaTeX output plus CSV and plain-text reference lists.

Carried over from the Streamlit project and improved:
  * proper TeX escaping (braces and backslashes were not handled before)
  * citation keys built from the *Latin* part of an author name, so
    "डॉ. राजेश व्ही. पाटील (Dr. Rajesh V. Patil)" -> "patil2023..."
  * keys are made unique inside a bibliography
  * CSV cells are protected against spreadsheet formula injection
  * every source type (book, article, web, report, patent) is supported

Extension fields (not part of standard BibTeX; ignored by classic .bst styles,
usable from BibLaTeX data models / custom styles):
    originaltitle, translatedtitle, transliteration, country
Standard fields used where they exist: translator, origdate, language, ...
"""
from __future__ import annotations

import csv
import io
import re
import unicodedata

from citation_engine import (
    FIELDS, STYLE_NAMES, TYPE_LABELS, bare_doi, generate_citation, normalize,
    to_plain,
)

_STOPWORDS = {"the", "and", "for", "with", "from", "into", "state", "report",
              "study", "analysis", "policy", "of", "on", "in", "an", "a"}

BIB_TYPES = {
    "book": "book",
    "journal": "article",
    "web": "online",
    "report": "techreport",
    "patent": "patent",
}


# --------------------------------------------------------------------------
# Escaping and keys
# --------------------------------------------------------------------------
def escape_bibtex(text: str) -> str:
    """Escape TeX special characters; Unicode (e.g. Devanagari) is untouched."""
    if not text:
        return ""
    out = []
    for ch in str(text):
        if ch == "\\":
            out.append(r"\textbackslash{}")
        elif ch in "&%$#_{}":
            out.append("\\" + ch)
        elif ch == "~":
            out.append(r"\textasciitilde{}")
        elif ch == "^":
            out.append(r"\textasciicircum{}")
        else:
            out.append(ch)
    return "".join(out)


def _ascii_only(text: str) -> str:
    """Keep only the Latin/ASCII part of a string (accents folded)."""
    folded = unicodedata.normalize("NFKD", text or "")
    folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
    return re.sub(r"[^\x00-\x7F]+", " ", folded)


def _alnum(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _surname_from_author(author: str) -> str:
    latin = _ascii_only(author)
    first = re.split(r"\s*(?:&|;|\band\b)\s*", latin, maxsplit=1, flags=re.I)[0]
    first = re.sub(r"[()\[\]]", " ", first)
    if "," in first:
        return _alnum(first.split(",")[0])
    words = re.findall(r"[A-Za-z][A-Za-z'\-]*", first)
    # skip honorific-only tokens such as "Dr"
    words = [w for w in words if w.lower().rstrip(".") not in {"dr", "prof", "mr", "mrs", "ms"}]
    return _alnum(words[-1]) if words else ""


def generate_citation_key(data: dict) -> str:
    """Deterministic, readable key such as 'patil2023maharashtra'."""
    r = normalize(data)
    author_key = _surname_from_author(r.author)
    if not author_key:
        publisher_words = re.findall(r"[A-Za-z]{4,}", _ascii_only(r.publisher))
        author_key = _alnum(publisher_words[0]) if publisher_words else "anon"
    year_key = _alnum(r.year) or "nd"
    for source in (r.title, r.transliteration, _ascii_only(r.original_title)):
        words = [w for w in re.findall(r"[A-Za-z]{4,}", source or "")
                 if w.lower() not in _STOPWORDS]
        if words:
            return f"{author_key}{year_key}{_alnum(words[0])}"
    return f"{author_key}{year_key}doc"


def unique_keys(records: list[dict]) -> list[str]:
    """Keys for a list of records, de-duplicated with a, b, c ... suffixes."""
    seen: dict[str, int] = {}
    keys = []
    for rec in records:
        base = generate_citation_key(rec)
        n = seen.get(base, 0)
        seen[base] = n + 1
        keys.append(base if n == 0 else f"{base}{chr(ord('a') + n - 1) if n <= 26 else n}")
    return keys


# --------------------------------------------------------------------------
# BibTeX
# --------------------------------------------------------------------------
def generate_bibtex(data: dict, key: str | None = None) -> str:
    r = normalize(data)
    key = key or generate_citation_key(data)
    lead, _gloss = r.title_parts()
    fields: list[tuple[str, str]] = []

    def add(name: str, value: str, braces: int = 1, raw: bool = False):
        if value:
            body = value if raw else escape_bibtex(value)
            fields.append((name, "{" * braces + body + "}" * braces))

    add("author", r.author)
    add("title", lead, braces=2)                       # {{...}} keeps case/script
    if r.original_title:
        add("originaltitle", r.original_title, braces=2)
    if r.non_english_original and r.title and r.title != lead:
        add("translatedtitle", r.title, braces=2)
    add("transliteration", r.transliteration, braces=2)
    add("translator", r.translator)
    add("language", r.language)
    add("edition", r.edition)
    add("journal", r.journal)
    add("volume", r.volume)
    add("number", r.issue if r.source_type == "journal" else r.identifier)
    add("pages", r.pages.replace("–", "--").replace("—", "--"))
    if r.source_type == "report":
        add("institution", r.publisher, braces=2)
    elif r.source_type == "patent":
        add("holder", r.publisher, braces=2)
    else:
        add("publisher", r.publisher)
    add("country", r.country)
    add("year", r.year)
    add("origdate", r.original_year)
    add("doi", bare_doi(r.doi), raw=True)
    add("url", r.url, raw=True)
    if r.access_date:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", r.access_date):
            add("urldate", r.access_date)
        else:
            add("note", f"Accessed: {r.access_date}")

    width = max((len(n) for n, _ in fields), default=0)
    body = ",\n".join(f"  {n.ljust(width)} = {v}" for n, v in fields)
    return f"@{BIB_TYPES[r.source_type]}{{{key},\n{body}\n}}"


BIB_HEADER = (
    "% =====================================================================\n"
    "% Multilingual BibTeX / BibLaTeX file\n"
    "% Generated by: Inclusive Citation Framework (educational prototype)\n"
    "% Encoding: UTF-8  (compile with XeLaTeX/LuaLaTeX + biblatex/biber)\n"
    "% Entry types @online and @patent are BibLaTeX types; with classic BibTeX\n"
    "% change them to @misc.\n"
    "% Extension fields (originaltitle, translatedtitle, transliteration,\n"
    "% country) are ignored by standard styles and need a custom data model\n"
    "% or .bst/.bbx style to be printed.\n"
    "% =====================================================================\n\n"
)


def export_bib(records: list[dict]) -> str:
    keys = unique_keys(records)
    entries = [generate_bibtex(rec, key) for rec, key in zip(records, keys)]
    return BIB_HEADER + "\n\n".join(entries) + "\n"


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------
CSV_COLUMNS = ["citation_key"] + FIELDS + [f"{s}_reference" for s in STYLE_NAMES]


def _csv_safe(value: str) -> str:
    """Neutralise cells that spreadsheets would execute as formulas."""
    value = "" if value is None else str(value)
    return "'" + value if value[:1] in ("=", "+", "-", "@", "\t", "\r") else value


def export_csv(records: list[dict]) -> str:
    keys = unique_keys(records)
    out = io.StringIO()
    writer = csv.writer(out, quoting=csv.QUOTE_ALL)
    writer.writerow(CSV_COLUMNS)
    for rec, key in zip(records, keys):
        r = normalize(rec)
        row = [key] + [getattr(r, f) for f in FIELDS]
        row += [to_plain(generate_citation(rec, s)) for s in STYLE_NAMES]
        writer.writerow([_csv_safe(c) for c in row])
    return out.getvalue()


# --------------------------------------------------------------------------
# Plain-text reference list
# --------------------------------------------------------------------------
def export_reference_list(records: list[dict], style: str) -> str:
    refs = [to_plain(generate_citation(rec, style)) for rec in records]
    if style == "IEEE":
        lines = [f"[{i}] {ref}" for i, ref in enumerate(refs, start=1)]
    else:  # APA / MLA lists are alphabetical
        lines = sorted(refs, key=lambda s: s.casefold())
    title = f"References ({style} draft)"
    return f"{title}\n{'=' * len(title)}\n\n" + "\n\n".join(lines) + "\n"


def type_counts(records: list[dict]) -> dict[str, int]:
    counts = {k: 0 for k in TYPE_LABELS}
    for rec in records:
        counts[normalize(rec).source_type] += 1
    return counts
