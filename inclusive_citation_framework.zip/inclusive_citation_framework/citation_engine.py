"""citation_engine.py
--------------------
Rule-based reference drafts (APA, MLA, IEEE) for non-English and translated
academic sources.

Supported source types: book, journal article, web page, government /
institutional report, and patent.

IMPORTANT: this is an educational prototype. Output is a *draft* that must be
checked against the current official style guidance. Author names are used
exactly as entered (no automatic name-order parsing).

Text produced here uses a tiny markup: ``*text*`` means italics. Use
:func:`to_html` or :func:`to_plain` to render it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from markupsafe import Markup, escape

# --------------------------------------------------------------------------
# Constants shared by the engine, validator, templates and JavaScript
# --------------------------------------------------------------------------
STYLE_NAMES = ["APA", "MLA", "IEEE"]

SOURCE_TYPES = [
    ("book", "Book"),
    ("journal", "Journal article"),
    ("web", "Web page"),
    ("report", "Government / institutional report"),
    ("patent", "Patent"),
]
TYPE_LABELS = dict(SOURCE_TYPES)

LANGUAGES = [
    "Arabic", "Bengali", "Chinese", "English", "French", "German", "Gujarati",
    "Hindi", "Japanese", "Kannada", "Malayalam", "Marathi", "Persian",
    "Portuguese", "Punjabi", "Russian", "Sanskrit", "Spanish", "Tamil",
    "Telugu", "Urdu",
]

# Every field the form can submit.
FIELDS = [
    "source_type", "author", "year", "title", "original_title",
    "transliteration", "language", "translator", "original_year",
    "title_display", "publisher", "journal", "volume", "issue", "pages",
    "edition", "doi", "url", "access_date", "country", "identifier",
]

# Fields used by every source type ...
COMMON_FIELDS = {
    "source_type", "author", "year", "title", "original_title",
    "transliteration", "language", "title_display", "publisher", "url",
}
# ... plus the extras that only make sense for a given type. Fields outside
# this set are ignored by the engine (so a value typed for a "book" cannot
# leak into a "web page" citation after the user switches type).
TYPE_EXTRA_FIELDS = {
    "book": {"edition", "translator", "original_year", "doi"},
    "journal": {"journal", "volume", "issue", "pages", "translator",
                "original_year", "doi"},
    "web": {"access_date"},
    "report": {"translator", "original_year", "doi", "country", "identifier"},
    "patent": {"country", "identifier"},
}

MAX_FIELD_LEN = 1000


def applicable_fields(source_type: str) -> set[str]:
    return COMMON_FIELDS | TYPE_EXTRA_FIELDS.get(source_type, set())


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def clean(value) -> str:
    """Collapse whitespace and drop '*' (reserved for italics markup)."""
    return " ".join(str(value or "").split()).replace("*", "")


def ital(text: str) -> str:
    return f"*{text}*" if text else ""


def _ends_with_terminal(text: str) -> bool:
    return text.rstrip("*")[-1:] in {".", "?", "!"}


def end(text: str) -> str:
    """Make sure a segment ends with terminal punctuation."""
    if not text:
        return ""
    return text if _ends_with_terminal(text) else text + "."


def join_nonempty(parts, sep=", ") -> str:
    return sep.join(p for p in parts if p)


def doi_url(doi: str) -> str:
    """Normalise a DOI to https://doi.org/<doi>."""
    d = clean(doi)
    d = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", d, flags=re.I)
    return f"https://doi.org/{d}" if d else ""


def bare_doi(doi: str) -> str:
    return doi_url(doi).removeprefix("https://doi.org/")


def has_non_latin(text: str) -> bool:
    return any(ord(ch) > 0x024F and ch.isalpha() for ch in text or "")


def pages_label(pages: str, style: str) -> str:
    """'pp. 31–48' for ranges, 'p. 7' for single numeric pages, raw otherwise."""
    if not pages:
        return ""
    if re.search(r"[-–—,]", pages):
        return f"pp. {pages}"
    if pages.isdigit():
        return f"p. {pages}"
    return pages  # article number such as e1234 - left as entered


# --------------------------------------------------------------------------
# Normalised record
# --------------------------------------------------------------------------
@dataclass
class Rec:
    source_type: str = "book"
    author: str = ""
    year: str = ""
    title: str = ""
    original_title: str = ""
    transliteration: str = ""
    language: str = ""
    translator: str = ""
    original_year: str = ""
    title_display: str = "native"
    publisher: str = ""
    journal: str = ""
    volume: str = ""
    issue: str = ""
    pages: str = ""
    edition: str = ""
    doi: str = ""
    url: str = ""
    access_date: str = ""
    country: str = ""
    identifier: str = ""

    # -- derived properties -------------------------------------------------
    @property
    def is_english(self) -> bool:
        return self.language.lower().startswith("english")

    @property
    def translated(self) -> bool:
        """The cited version is a translation (a translator is named)."""
        return bool(self.translator)

    @property
    def non_english_original(self) -> bool:
        """The cited version is itself non-English (no translator named)."""
        return (not self.translated and not self.is_english
                and bool(self.language or self.original_title))

    @property
    def y(self) -> str:
        return self.year or "n.d."

    def title_parts(self) -> tuple[str, str]:
        """Return (lead_title, english_gloss).

        * translated edition  -> the published (translated) title, no gloss
        * non-English source  -> original-language title + [English translation]
        * otherwise           -> the title as entered
        """
        if self.non_english_original:
            lead = self.original_title or self.title
            if self.title_display == "translit" and self.transliteration:
                lead = self.transliteration
            gloss = self.title if (self.original_title and self.title
                                   and self.title != lead) else ""
            return lead, gloss
        return (self.title or self.original_title), ""

    @property
    def language_marker(self) -> str:
        return f"(in {self.language})" if self.non_english_original and self.language else ""


def normalize(data: dict) -> Rec:
    """Build a Rec from raw form data, ignoring fields that do not apply."""
    source_type = clean(data.get("source_type")) or "book"
    if source_type not in TYPE_LABELS:
        source_type = "book"
    allowed = applicable_fields(source_type)
    values = {f: (clean(data.get(f)) if f in allowed else "") for f in FIELDS}
    values["source_type"] = source_type
    if values["title_display"] not in ("native", "translit"):
        values["title_display"] = "native"
    return Rec(**values)


# --------------------------------------------------------------------------
# APA (7th ed.-style draft)
# --------------------------------------------------------------------------
def _apa_title(r: Rec, italic: bool, *, with_edition=True, id_label="") -> str:
    lead, gloss = r.title_parts()
    text = ital(lead) if italic else lead
    if gloss:
        text += f" [{gloss}]"
    notes = []
    if with_edition and r.edition:
        notes.append(r.edition)
    if r.translator:
        notes.append(f"{r.translator}, Trans.")
    if notes:
        text += f" ({', '.join(notes)})"
    if id_label:
        text += f" ({id_label})"
    return text


def _apa_lead(r: Rec, title_block: str) -> list[str]:
    """Author + date + title, or title + date when there is no author."""
    if r.author:
        return [end(r.author), f"({r.y}).", end(title_block)]
    return [end(title_block), f"({r.y})."]


def _apa(r: Rec) -> str:
    link = doi_url(r.doi) or r.url
    original = f"(Original work published {r.original_year})" if r.original_year else ""
    t = r.source_type

    if t == "journal":
        parts = _apa_lead(r, _apa_title(r, False, with_edition=False))
        vol = ital(r.volume) + (f"({r.issue})" if r.issue else "") if r.volume \
            else (f"({r.issue})" if r.issue else "")
        source = end(join_nonempty([ital(r.journal), vol, r.pages]))
        parts += [source, link, original]
    elif t == "web":
        parts = _apa_lead(r, _apa_title(r, True, with_edition=False))
        if r.publisher and r.publisher != r.author:
            parts.append(end(r.publisher))
        if r.access_date and r.url:
            parts.append(f"Retrieved {r.access_date}, from {r.url}")
        else:
            parts.append(r.url)
    elif t == "report":
        label = f"Report No. {r.identifier}" if r.identifier else ""
        parts = _apa_lead(r, _apa_title(r, True, with_edition=False, id_label=label))
        if r.publisher and r.publisher != r.author:
            parts.append(end(r.publisher))
        parts += [link, original]
    elif t == "patent":
        label = (f"{r.country} Patent No. {r.identifier}" if r.country
                 else f"Patent No. {r.identifier}") if r.identifier else ""
        parts = _apa_lead(r, _apa_title(r, True, with_edition=False, id_label=label))
        if r.publisher:
            parts.append(end(r.publisher))
        parts.append(r.url)
    else:  # book
        parts = _apa_lead(r, _apa_title(r, True))
        if r.publisher and r.publisher != r.author:
            parts.append(end(r.publisher))
        parts += [link, original]
    return " ".join(p for p in parts if p)


# --------------------------------------------------------------------------
# MLA (9th ed.-style draft)
# --------------------------------------------------------------------------
def _mla_title(r: Rec, italic: bool) -> str:
    lead, gloss = r.title_parts()
    if italic:
        return end(ital(lead) + (f" [{gloss}]" if gloss else ""))
    return f'"{lead}{" [" + gloss + "]" if gloss else ""}."'


def _mla(r: Rec) -> str:
    link = doi_url(r.doi) or r.url
    translated_by = f"Translated by {r.translator}" if r.translator else ""
    author = end(r.author)
    t = r.source_type

    if t == "journal":
        pieces = [ital(r.journal),
                  f"translated by {r.translator}" if r.translator else "",
                  f"vol. {r.volume}" if r.volume else "",
                  f"no. {r.issue}" if r.issue else "", r.year,
                  pages_label(r.pages, "MLA"), link]
        body = _mla_title(r, False) + " " + end(join_nonempty(pieces))
        return join_nonempty([author, body], " ")
    if t == "web":
        pieces = [ital(r.publisher), r.year, r.url]
        body = _mla_title(r, False) + " " + end(join_nonempty(pieces))
        if r.access_date and r.url:
            body += f" Accessed {r.access_date}."
        return join_nonempty([author, body.strip()], " ")
    if t == "report":
        pieces = [translated_by, f"Report no. {r.identifier}" if r.identifier else "",
                  r.publisher, r.year, link]
    elif t == "patent":
        number = (f"{r.country} Patent {r.identifier}" if r.country
                  else f"Patent no. {r.identifier}") if r.identifier else ""
        pieces = [number, r.publisher, r.year, r.url]
    else:  # book
        pieces = [translated_by, r.edition, r.publisher, r.year, link]
    body = _mla_title(r, True) + " " + end(join_nonempty(pieces))
    return join_nonempty([author, body.strip()], " ")


# --------------------------------------------------------------------------
# IEEE (reference-guide-style draft); the "[n]" label is added by the caller
# --------------------------------------------------------------------------
def _ieee_title(r: Rec, italic: bool) -> str:
    lead, gloss = r.title_parts()
    base = (ital(lead) if italic else lead) + (f" [{gloss}]" if gloss else "")
    return base


def _ieee(r: Rec) -> str:
    marker = r.language_marker
    translator = f"{r.translator}, Trans." if r.translator else ""
    t = r.source_type

    def quoted_head() -> str:
        title = f'"{_ieee_title(r, False)},"'
        return f"{r.author}, {title}" if r.author else title

    def finish(text: str, link_part: str = "") -> str:
        text = end(text)
        if link_part:
            text += " " + link_part
        if marker:
            text += " " + marker
        return text.strip()

    if t == "journal":
        pieces = [ital(r.journal), translator,
                  f"vol. {r.volume}" if r.volume else "",
                  f"no. {r.issue}" if r.issue else "",
                  pages_label(r.pages, "IEEE"), r.year,
                  f"doi: {bare_doi(r.doi)}" if r.doi else r.url]
        return finish(quoted_head() + " " + join_nonempty(pieces))
    if t == "web":
        text = quoted_head() + " " + join_nonempty([r.publisher, r.year])
        text = end(text.strip())
        link = f"[Online]. Available: {r.url}" if r.url else ""
        if r.access_date and r.url:
            link = f"Accessed: {r.access_date}. {link}"
        return finish(text, link.strip())
    if t == "report":
        pieces = [r.publisher, r.country,
                  f"Rep. {r.identifier}" if r.identifier else "", r.year]
        link = f"[Online]. Available: {doi_url(r.doi) or r.url}" if (r.doi or r.url) else ""
        return finish(quoted_head() + " " + join_nonempty(pieces), link)
    if t == "patent":
        number = (f"{r.country} Patent {r.identifier}" if r.country
                  else f"{r.publisher + ', ' if r.publisher else ''}Patent {r.identifier}") \
            if r.identifier else (r.country or r.publisher)
        link = f"[Online]. Available: {r.url}" if r.url else ""
        return finish(quoted_head() + " " + join_nonempty([number, r.year]), link)
    # book
    left = join_nonempty([r.author, _ieee_title(r, True), r.edition, translator])
    tail = join_nonempty([r.publisher, r.year])
    text = end(left) + (" " + tail if tail else "")
    link = f"[Online]. Available: {doi_url(r.doi) or r.url}" if (r.doi or r.url) else ""
    return finish(text, link)


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------
_FORMATTERS = {"APA": _apa, "MLA": _mla, "IEEE": _ieee}


def generate_citation(data: dict, style: str) -> str:
    """Return the draft reference (italic markup, no IEEE number)."""
    if style not in _FORMATTERS:
        raise ValueError(f"Unsupported style: {style!r}")
    return _FORMATTERS[style](normalize(data))


def to_plain(markup: str) -> str:
    return markup.replace("*", "")


def to_html(markup: str) -> Markup:
    """Escape text and turn *italic* markup into <i> tags."""
    safe = str(escape(markup))
    return Markup(re.sub(r"\*(.+?)\*", r"<i>\1</i>", safe))


def current_year() -> int:
    return date.today().year
