import unittest

from citation_engine import generate_citation, normalize, to_html, to_plain
from sample_data import SAMPLES


def plain(data, style):
    return to_plain(generate_citation(data, style))


class EnglishSourceTests(unittest.TestCase):
    book = {"source_type": "book", "author": "Smith, J.", "year": "2020",
            "title": "Research Methods", "publisher": "Oxford University Press",
            "edition": "2nd ed."}

    def test_apa_book(self):
        self.assertEqual(plain(self.book, "APA"),
                         "Smith, J. (2020). Research Methods (2nd ed.). Oxford University Press.")

    def test_mla_book(self):
        self.assertEqual(plain(self.book, "MLA"),
                         "Smith, J. Research Methods. 2nd ed., Oxford University Press, 2020.")

    def test_ieee_book(self):
        self.assertEqual(plain(self.book, "IEEE"),
                         "Smith, J., Research Methods, 2nd ed. Oxford University Press, 2020.")

    def test_no_double_periods(self):
        for style in ("APA", "MLA", "IEEE"):
            self.assertNotIn("..", plain(self.book, style))

    def test_italics_markup_only_on_titles(self):
        self.assertEqual(generate_citation(self.book, "APA"),
                         "Smith, J. (2020). *Research Methods* (2nd ed.). Oxford University Press.")
        self.assertIn("<i>Research Methods</i>", str(to_html(generate_citation(self.book, "APA"))))

    def test_missing_year_uses_nd_in_apa(self):
        d = dict(self.book, year="")
        self.assertIn("(n.d.)", plain(d, "APA"))

    def test_no_author_moves_title_first(self):
        d = dict(self.book, author="")
        self.assertTrue(plain(d, "APA").startswith("Research Methods (2nd ed.). (2020)."))
        self.assertTrue(plain(d, "MLA").startswith("Research Methods."))

    def test_title_ending_with_question_mark(self):
        d = dict(self.book, title="Why Cite?", edition="")
        self.assertIn("(2020). Why Cite?", plain(d, "APA"))
        self.assertNotIn("?.", plain(d, "APA"))

    def test_apa_journal_with_doi(self):
        d = {"source_type": "journal", "author": "Lee, K.", "year": "2021",
             "title": "On Things", "journal": "Journal of Stuff", "volume": "12",
             "issue": "3", "pages": "45-67", "doi": "doi:10.1000/xyz123"}
        self.assertEqual(plain(d, "APA"),
                         "Lee, K. (2021). On Things. Journal of Stuff, 12(3), 45-67. https://doi.org/10.1000/xyz123")
        self.assertEqual(plain(d, "IEEE"),
                         'Lee, K., "On Things," Journal of Stuff, vol. 12, no. 3, pp. 45-67, 2021, doi: 10.1000/xyz123.')
        self.assertEqual(plain(d, "MLA"),
                         'Lee, K. "On Things." Journal of Stuff, vol. 12, no. 3, 2021, pp. 45-67, https://doi.org/10.1000/xyz123.')

    def test_apa_web_does_not_repeat_url(self):
        # regression: the original Flask prototype printed the URL twice
        d = {"source_type": "web", "author": "WHO", "year": "2024", "title": "Fact sheet",
             "publisher": "World Health Organization", "url": "https://example.org/x",
             "access_date": "30 October 2026"}
        out = plain(d, "APA")
        self.assertEqual(out.count("https://example.org/x"), 1)
        self.assertIn("Retrieved 30 October 2026, from https://example.org/x", out)


class MultilingualTests(unittest.TestCase):
    def test_non_english_original_uses_bracketed_translation(self):
        d = SAMPLES[1]["data"]
        self.assertIn("ग्रामीण शिक्षा में डिजिटल साधनों की भूमिका [The Role of Digital Tools in Rural Education]",
                      plain(d, "APA"))
        self.assertTrue(plain(d, "IEEE").endswith("(in Hindi)"))

    def test_translated_edition_credits_translator_and_original_year(self):
        d = SAMPLES[0]["data"]
        self.assertEqual(
            plain(d, "APA"),
            "Tagore, Rabindranath. (1913). Gitanjali (Song Offerings) (Rabindranath Tagore, Trans.). "
            "Macmillan. (Original work published 1910)")
        self.assertNotIn("(in Bengali)", plain(d, "IEEE"))   # the cited book is English
        self.assertIn("Translated by Rabindranath Tagore", plain(d, "MLA"))

    def test_translator_name_keeps_its_case_in_mla_journal(self):
        d = {"source_type": "journal", "author": "A", "year": "2000", "title": "T",
             "journal": "J", "translator": "Ravi Kumar"}
        self.assertIn("translated by Ravi Kumar", plain(d, "MLA"))

    def test_transliteration_display_option(self):
        d = dict(SAMPLES[1]["data"], title_display="translit")
        out = plain(d, "APA")
        self.assertIn("Gramin shiksha mein digital sadhanon ki bhumika [The Role", out)
        self.assertNotIn("ग्रामीण", out)

    def test_transliteration_option_without_value_falls_back_to_native(self):
        d = dict(SAMPLES[1]["data"], transliteration="", title_display="translit")
        self.assertIn("ग्रामीण", plain(d, "APA"))

    def test_report_and_patent_in_all_styles(self):
        report, patent = SAMPLES[3]["data"], SAMPLES[4]["data"]
        self.assertIn("(Report No. WRD-MH-2023-REP-04)", plain(report, "APA"))
        self.assertIn("Rep. WRD-MH-2023-REP-04", plain(report, "IEEE"))
        self.assertIn("(India Patent No. IN-2022-41058291-A)", plain(patent, "APA"))
        self.assertIn("India Patent IN-2022-41058291-A", plain(patent, "MLA"))
        self.assertIn("India Patent IN-2022-41058291-A", plain(patent, "IEEE"))

    def test_ieee_web_puts_accessed_before_online(self):
        out = plain(SAMPLES[2]["data"], "IEEE")
        self.assertLess(out.index("Accessed:"), out.index("[Online]"))


class IsolationTests(unittest.TestCase):
    def test_fields_of_other_types_are_ignored(self):
        # user fills journal fields, then switches the type to "web"
        d = {"source_type": "web", "author": "A", "year": "2020", "title": "T",
             "journal": "Hidden Journal", "volume": "9", "translator": "Hidden T.",
             "url": "https://example.org"}
        out = plain(d, "APA")
        self.assertNotIn("Hidden", out)
        r = normalize(d)
        self.assertEqual((r.journal, r.volume, r.translator), ("", "", ""))

    def test_unknown_type_falls_back_to_book(self):
        self.assertEqual(normalize({"source_type": "bogus"}).source_type, "book")

    def test_unknown_style_raises(self):
        with self.assertRaises(ValueError):
            generate_citation({}, "Chicago")

    def test_html_escaping_and_asterisks(self):
        d = {"source_type": "book", "author": "<b>x</b>", "year": "2020", "title": "*bold* <script>"}
        html = str(to_html(generate_citation(d, "APA")))
        self.assertNotIn("<script>", html)
        self.assertNotIn("<b>", html)
        self.assertNotIn("*bold*", plain(d, "APA"))


if __name__ == "__main__":
    unittest.main()
