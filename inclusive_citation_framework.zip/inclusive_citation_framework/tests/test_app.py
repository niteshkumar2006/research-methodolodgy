import csv
import io
import re
import unittest

from app import app, library
from sample_data import SAMPLES


def token_from(html: str) -> str:
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


class AppTestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()
        self.token = token_from(self.client.get("/").get_data(as_text=True))

    def post(self, url, data=None, **kw):
        payload = dict(data or {}, csrf_token=self.token)
        return self.client.post(url, data=payload, **kw)

    def sample(self, i):
        return dict(SAMPLES[i]["data"])


class PageTests(AppTestCase):
    def test_pages_render(self):
        for url in ("/", "/library", "/about"):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_404_uses_friendly_template(self):
        r = self.client.get("/nope")
        self.assertEqual(r.status_code, 404)
        self.assertIn("Back to the generator", r.get_data(as_text=True))

    def test_security_headers(self):
        h = self.client.get("/").headers
        self.assertIn("default-src 'self'", h["Content-Security-Policy"])
        self.assertEqual(h["X-Content-Type-Options"], "nosniff")

    def test_no_inline_scripts_or_handlers_that_csp_would_block(self):
        html = self.client.get("/").get_data(as_text=True)
        self.assertNotRegex(html, r"\sonclick=|\sonchange=|\sstyle=")
        for m in re.finditer(r"<script(?![^>]*(src=|application/json))[^>]*>", html):
            self.fail("inline script found: " + m.group(0))


class GeneratorTests(AppTestCase):
    def test_generate_all_samples(self):
        for i, s in enumerate(SAMPLES):
            r = self.post("/", self.sample(i))
            html = r.get_data(as_text=True)
            self.assertEqual(r.status_code, 200, s["label"])
            for style in ("APA", "MLA", "IEEE"):
                self.assertIn(f'id="citation-{style}"', html)
            self.assertIn('id="citation-bibtex"', html)
            self.assertIn("Save to library", html)

    def test_ieee_gets_number_one_and_italics_render(self):
        html = self.post("/", self.sample(0)).get_data(as_text=True)
        self.assertIn("[1] Tagore", html)
        self.assertIn("<i>Gitanjali (Song Offerings)</i>", html)

    def test_errors_block_output(self):
        html = self.post("/", {"source_type": "book", "title": ""}).get_data(as_text=True)
        self.assertIn("A title is required", html)
        self.assertNotIn('id="citation-APA"', html)

    def test_form_values_are_kept_after_submit(self):
        html = self.post("/", self.sample(3)).get_data(as_text=True)
        self.assertIn("WRD-MH-2023-REP-04", html)
        self.assertIn('value="Marathi"', html)

    def test_xss_is_escaped_everywhere(self):
        evil = {"source_type": "book", "title": "<script>alert(1)</script>",
                "author": '"><img src=x onerror=alert(1)>', "year": "2020", "publisher": "P"}
        html = self.post("/", evil).get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertNotIn("<img src=x", html)

    def test_oversized_field_is_truncated(self):
        html = self.post("/", {"source_type": "book", "title": "x" * 5000}).get_data(as_text=True)
        self.assertNotIn("x" * 1001, html)

    def test_single_bib_download(self):
        r = self.post("/download/bib", self.sample(4))
        self.assertEqual(r.status_code, 200)
        self.assertIn("sharma2022solar.bib", r.headers["Content-Disposition"])
        self.assertIn("@patent{sharma2022solar", r.get_data(as_text=True))

    def test_single_bib_download_rejects_invalid(self):
        self.assertEqual(self.post("/download/bib", {"title": ""}).status_code, 400)


class CsrfTests(AppTestCase):
    def test_post_without_token_rejected(self):
        for url in ("/", "/library/add", "/library/clear", "/download/bib"):
            self.assertEqual(self.client.post(url, data=self.sample(0)).status_code, 400, url)

    def test_post_with_wrong_token_rejected(self):
        r = self.client.post("/", data=dict(self.sample(0), csrf_token="forged"))
        self.assertEqual(r.status_code, 400)

    def test_fresh_client_without_session_cannot_post(self):
        r = app.test_client().post("/", data=dict(self.sample(0), csrf_token=self.token))
        self.assertEqual(r.status_code, 400)


class LibraryTests(AppTestCase):
    def test_add_view_dedupe_remove_clear(self):
        r = self.post("/library/add", self.sample(3))
        self.assertEqual(r.status_code, 302)
        page = self.client.get("/library").get_data(as_text=True)
        self.assertIn("patil2023maharashtra", page)
        self.assertIn("Saved to your library", page)

        self.post("/library/add", self.sample(3))                     # duplicate
        page = self.client.get("/library").get_data(as_text=True)
        self.assertIn("already in your library", page)
        self.assertEqual(page.count("<tr><td>"), 1)

        self.post("/library/add", self.sample(4))
        page = self.client.get("/library").get_data(as_text=True)
        self.assertEqual(page.count("<tr><td>"), 2)

        rid = re.search(r"/library/remove/([0-9a-f]+)", page).group(1)
        self.post(f"/library/remove/{rid}")
        page = self.client.get("/library").get_data(as_text=True)
        self.assertEqual(page.count("<tr><td>"), 1)

        self.post("/library/clear")                                   # no confirmation
        self.assertEqual(self.client.get("/library").get_data(as_text=True).count("<tr><td>"), 1)
        self.post("/library/clear", {"confirm": "yes"})
        self.assertIn("Your library is empty", self.client.get("/library").get_data(as_text=True))

    def test_add_rejects_invalid_record(self):
        r = self.post("/library/add", {"source_type": "patent", "title": "T"})  # no patent number
        self.assertEqual(r.status_code, 400)
        self.assertIn("Your library is empty", self.client.get("/library").get_data(as_text=True))

    def test_libraries_are_isolated_per_session(self):
        self.post("/library/add", self.sample(0))
        other = app.test_client()
        tok = token_from(other.get("/").get_data(as_text=True))
        self.assertIn("Your library is empty", other.get("/library").get_data(as_text=True))
        other.post("/library/add", data=dict(self.sample(1), csrf_token=tok))
        mine = self.client.get("/library").get_data(as_text=True)
        self.assertIn("tagore1913gitanjali", mine)
        self.assertNotIn("sharma2022role", mine)

    def test_remove_unknown_id_is_harmless(self):
        r = self.post("/library/remove/doesnotexist", follow_redirects=True)
        self.assertIn("not found", r.get_data(as_text=True))

    def test_exports(self):
        for i in range(5):
            self.post("/library/add", self.sample(i))

        bib = self.client.get("/library/export/bib")
        self.assertEqual(bib.status_code, 200)
        text = bib.get_data(as_text=True)
        self.assertEqual(text.count("\n@"), 5)
        self.assertIn(SAMPLES[0]["data"]["original_title"], text)   # Bengali script survives

        raw_csv = self.client.get("/library/export/csv").data
        self.assertTrue(raw_csv.startswith(b"\xef\xbb\xbf"))          # BOM for Excel
        rows = list(csv.reader(io.StringIO(raw_csv.decode("utf-8-sig"))))
        self.assertEqual(len(rows), 6)

        txt = self.client.get("/library/export/txt?style=IEEE").get_data(as_text=True)
        self.assertIn("[5] ", txt)
        self.assertEqual(self.client.get("/library/export/txt?style=Bogus").status_code, 400)
        self.assertEqual(self.client.get("/library/export/pdf").status_code, 404)

    def test_export_when_empty_redirects(self):
        r = self.client.get("/library/export/bib")
        self.assertEqual(r.status_code, 302)

    def test_library_cap(self):
        original = library.max_records
        library.max_records = 2
        try:
            for i in range(3):
                self.post("/library/add", self.sample(i))
            page = self.client.get("/library").get_data(as_text=True)
            self.assertEqual(page.count("<tr><td>"), 2)
        finally:
            library.max_records = original


if __name__ == "__main__":
    unittest.main()
