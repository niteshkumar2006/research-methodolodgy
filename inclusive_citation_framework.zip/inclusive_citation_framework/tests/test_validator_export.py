import csv
import io
import unittest

from bibtex_export import (escape_bibtex, export_bib, export_csv,
                           export_reference_list, generate_bibtex,
                           generate_citation_key, unique_keys)
from citation_engine import current_year
from sample_data import SAMPLES
from validator import validate_source


def errs(d):
    return validate_source(d)[0]


def warns(d):
    return validate_source(d)[1]


class ValidatorTests(unittest.TestCase):
    base = {"source_type": "book", "author": "A", "year": "2020", "title": "T", "publisher": "P"}

    def test_clean_record_has_no_errors_or_warnings(self):
        self.assertEqual(validate_source(self.base), ([], []))

    def test_title_or_original_title_required(self):
        self.assertTrue(errs(dict(self.base, title="")))
        self.assertFalse(errs(dict(self.base, title="", original_title="शीर्षक", language="Hindi")))

    def test_year_rules(self):
        self.assertTrue(errs(dict(self.base, year="20x0")))
        self.assertTrue(errs(dict(self.base, year=str(current_year() + 5))))
        self.assertFalse(errs(dict(self.base, year=str(current_year()))))
        self.assertTrue(any("earlier than 1800" in w for w in warns(dict(self.base, year="1750"))))
        self.assertTrue(any("blank" in w for w in warns(dict(self.base, year=""))))

    def test_url_must_be_http(self):
        self.assertTrue(errs(dict(self.base, url="javascript:alert(1)")))
        self.assertTrue(errs(dict(self.base, url="example.org")))
        self.assertFalse(errs(dict(self.base, url="https://example.org/a")))

    def test_bad_doi_is_only_a_warning(self):
        d = dict(self.base, doi="not-a-doi")
        self.assertFalse(errs(d))
        self.assertTrue(any("DOI" in w for w in warns(d)))
        self.assertFalse(any("DOI" in w for w in warns(dict(self.base, doi="https://doi.org/10.1000/abc"))))

    def test_patent_requires_number(self):
        d = {"source_type": "patent", "author": "A", "year": "2020", "title": "T", "publisher": "Office", "country": "India"}
        self.assertTrue(errs(d))
        self.assertFalse(errs(dict(d, identifier="IN-1")))

    def test_invalid_source_type_is_an_error(self):
        self.assertTrue(errs(dict(self.base, source_type="podcast")))

    def test_translation_warnings(self):
        d = dict(self.base, translator="R. Kumar", language="Hindi")
        w = " ".join(warns(d))
        self.assertIn("original title is blank", w)
        self.assertIn("original publication year", w)

    def test_non_latin_title_without_transliteration_warns(self):
        d = dict(SAMPLES[1]["data"], transliteration="")
        self.assertTrue(any("transliteration" in w.lower() for w in warns(d)))
        self.assertFalse(any("Latin transliteration is optional" in w for w in warns(SAMPLES[1]["data"])))

    def test_original_year_after_publication_year_warns(self):
        d = dict(self.base, translator="T", original_title="O", language="French", original_year="2021")
        self.assertTrue(any("later than" in w for w in warns(d)))

    def test_all_samples_are_error_free(self):
        for s in SAMPLES:
            self.assertEqual(errs(s["data"]), [], s["label"])


class KeyAndEscapeTests(unittest.TestCase):
    def test_key_uses_latin_surname_for_devanagari_author(self):
        self.assertEqual(generate_citation_key(SAMPLES[3]["data"]), "patil2023maharashtra")
        self.assertEqual(generate_citation_key(SAMPLES[4]["data"]), "sharma2022solar")

    def test_key_from_comma_form_and_missing_author(self):
        self.assertEqual(generate_citation_key(SAMPLES[0]["data"]), "tagore1913gitanjali")
        self.assertEqual(generate_citation_key(SAMPLES[2]["data"]), "example2024guidelines")

    def test_key_never_empty(self):
        key = generate_citation_key({"source_type": "book", "title": "ग्रंथ"})
        self.assertRegex(key, r"^[a-z0-9]+$")

    def test_unique_keys_get_suffixes(self):
        recs = [SAMPLES[3]["data"]] * 3
        self.assertEqual(unique_keys(recs),
                         ["patil2023maharashtra", "patil2023maharashtraa", "patil2023maharashtrab"])

    def test_escape(self):
        self.assertEqual(escape_bibtex("R&D 50% #1 a_b $x {y} \\z"),
                         r"R\&D 50\% \#1 a\_b \$x \{y\} \textbackslash{}z")
        self.assertEqual(escape_bibtex("गीतांजली"), "गीतांजली")


class BibtexTests(unittest.TestCase):
    def test_entry_types(self):
        types = [generate_bibtex(s["data"]).split("{")[0] for s in SAMPLES]
        self.assertEqual(types, ["@book", "@article", "@online", "@techreport", "@patent"])

    def test_extension_fields_and_unicode_preserved(self):
        bib = generate_bibtex(SAMPLES[3]["data"])
        self.assertIn("originaltitle", bib)
        self.assertIn("translatedtitle", bib)
        self.assertIn("transliteration", bib)
        self.assertIn("महाराष्ट्र राज्य जल संवर्धन", bib)
        self.assertIn("institution", bib)

    def test_patent_has_number_and_holder(self):
        bib = generate_bibtex(SAMPLES[4]["data"])
        self.assertIn("number          = {IN-2022-41058291-A}", bib)
        self.assertIn("holder", bib)

    def test_braces_are_balanced_even_with_hostile_input(self):
        d = {"source_type": "book", "title": "Evil } title {", "author": "A}{B", "year": "2020"}
        bib = generate_bibtex(d)
        body = bib.replace(r"\{", "").replace(r"\}", "")
        self.assertEqual(body.count("{"), body.count("}"))

    def test_translated_book_uses_standard_fields(self):
        bib = generate_bibtex(SAMPLES[0]["data"])
        self.assertIn("translator", bib)
        self.assertIn("origdate        = {1910}", bib)
        self.assertNotIn("translatedtitle", bib)   # cited version is already English

    def test_urldate_only_for_iso_dates(self):
        d = dict(SAMPLES[2]["data"], access_date="2026-10-30")
        self.assertIn("urldate", generate_bibtex(d))
        self.assertIn("note", generate_bibtex(SAMPLES[2]["data"]))

    def test_export_bib_header_and_all_entries(self):
        text = export_bib([s["data"] for s in SAMPLES])
        self.assertTrue(text.startswith("% ====="))
        self.assertEqual(text.count("\n@"), 5)


class CsvAndListTests(unittest.TestCase):
    def test_csv_round_trip_and_columns(self):
        rows = list(csv.reader(io.StringIO(export_csv([s["data"] for s in SAMPLES]))))
        self.assertEqual(len(rows), 6)
        self.assertEqual(rows[0][0], "citation_key")
        self.assertEqual(rows[0][-3:], ["APA_reference", "MLA_reference", "IEEE_reference"])
        self.assertTrue(all(len(r) == len(rows[0]) for r in rows))

    def test_csv_formula_injection_is_neutralised(self):
        d = {"source_type": "book", "title": "=HYPERLINK(\"http://evil\")", "author": "+cmd", "year": "2020"}
        rows = list(csv.reader(io.StringIO(export_csv([d]))))
        self.assertTrue(rows[1][rows[0].index("title")].startswith("'="))
        self.assertTrue(rows[1][rows[0].index("author")].startswith("'+"))

    def test_reference_lists(self):
        recs = [s["data"] for s in SAMPLES]
        ieee = export_reference_list(recs, "IEEE")
        self.assertIn("[1] ", ieee)
        self.assertIn("[5] ", ieee)
        apa = export_reference_list(recs, "APA")
        self.assertNotIn("[1] ", apa)
        body = [b for b in apa.split("\n\n")[1:] if b.strip()]
        self.assertEqual(body, sorted(body, key=str.casefold))


if __name__ == "__main__":
    unittest.main()
