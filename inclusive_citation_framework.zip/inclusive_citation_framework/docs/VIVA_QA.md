# Viva questions and answers

Prepared for the merged **Inclusive Citation Framework** (Flask, APA/MLA/IEEE + extended BibTeX).

### Q1. What is the project and what problem does it solve?
Citation styles and tools were designed around English-language sources. When a source is in Marathi, Hindi,
Tamil or another language, or is a translated edition, references often lose the original-script title, the
translator, the original publication year or the language. The project captures this metadata and drafts
APA, MLA and IEEE references plus extended BibTeX, and flags incomplete records.

### Q2. What is BibTeX and why is it hard to use for multilingual sources?
BibTeX (1985, Oren Patashnik with Leslie Lamport) stores references in a `.bib` file and a `.bst` style formats
them. It has a single `title` field, so authors must choose between the native script and an English
translation, and it was designed around ASCII-era assumptions. Full Unicode works reliably only with
BibLaTeX + biber (or XeLaTeX/LuaLaTeX).

### Q3. Which source types does it support, and why reports and patents?
Books, journal articles, web pages, government/institutional reports and patents. Regional-language government
reports and patents are easy to lose from the literature: readers need the original title and official number
to find them, and classic BibTeX has no first-class patent type.

### Q4. How does it tell “citing a non-English original” from “citing a translated edition”?
If a translator is entered, the cited version is a translation: it prints the translated title, the
translator and the original publication year (APA: “Original work published …”). If the language is not
English and there is no translator, the cited version is the original: it prints the original-language title
followed by the English translation in square brackets (and “(in Language)” in IEEE).

### Q5. How are Unicode and regional scripts handled?
Everything is UTF-8 end to end: Python 3 strings, HTML (`<meta charset="utf-8">`), `.bib` files, and `.csv`
files written with a BOM so Excel displays Indic scripts. In BibTeX the title is wrapped in `{{…}}` to protect
script and capitalisation from the style.

### Q6. What are the BibTeX extension fields, and what happens to them in classic BibTeX?
`originaltitle`, `translatedtitle`, `transliteration` and `country`. Standard BibTeX ignores fields its style
does not define, so they never cause errors; they print only through a BibLaTeX data model or custom style.
Where a standard BibLaTeX field exists (`translator`, `origdate`, `language`, `holder`, `institution`,
`number`) it is used instead of inventing a new one.

### Q7. Why `@techreport` and `@patent`?
`@techreport` is the standard type for reports issued by an institution (fields `institution`, `number`).
`@patent` is a first-class BibLaTeX type (holder, number) and is more precise than a generic `@misc`.
`@online` is used for web pages; with classic BibTeX, change `@online`/`@patent` to `@misc`.

### Q8. How does the validation work? Why do some problems block and others only warn?
Errors block output that would be meaningless or malformed: no title at all, a malformed or future year, an
invalid URL, or a patent without a number. Everything else (missing publisher, non-Latin title without
transliteration, translator without original year, …) is a warning, because a record can still be cited
while being incomplete. The validator never checks whether the metadata is *true*.

### Q9. How does the web application keep the user's library between requests?
Flask's signed session cookie stores a random session id and a CSRF token; the records themselves are kept in
server memory under that id (`library.py`), so each browser has its own library. There is no database on
purpose, so records are lost when the server restarts, which is why `.bib`, `.csv` and text exports exist.

### Q10. Why Flask and plain Python instead of a database or machine-learning?
Citation formatting is deterministic string transformation under explicit rules; it needs no model or database.
A rule-based design is transparent, testable and reproducible, which suits a research-methodology project
(parsimony). Flask keeps the dependency list to one package.

### Q11. How do APA, MLA and IEEE differ for the same source?
APA is author–date (`Author. (Year). *Title*. Publisher.`); MLA is author–page style (`Author. *Title*.
Publisher, Year.`) with “vol./no./pp.” labels; IEEE is numbered (`[1] A. Author, “Title,” Journal, vol., no.,
pp., year.`). The framework generates all three from one record so the user can compare them.

### Q12. What are the limitations, and how would you evaluate accuracy?
It is an educational prototype: names are used as entered, report/patent patterns are adaptations, metadata
is not verified, and titles are not auto-translated or transliterated. To evaluate: build a test set of real
multilingual sources, define a scoring rubric first, have a human compare output to the official guidance,
and report sample size, rubric and failures. No accuracy percentage should be claimed before that.

### Q13. How is the application secured?
CSRF tokens on every POST, a strict Content-Security-Policy (no inline scripts), HTML-escaped output, input
length limits, TeX escaping for `.bib`, formula-injection protection for `.csv`, and debug mode off by
default.
