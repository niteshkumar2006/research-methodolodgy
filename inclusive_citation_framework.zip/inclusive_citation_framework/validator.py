"""validator.py
------------
Merged validation rules.

* errors   -> block generation (the output would be meaningless or malformed)
* warnings -> advisory; the citation is still generated

Philosophy (kept from both earlier projects): flag what looks incomplete or
inconsistent instead of silently implying the citation is fully compliant.
The validator never checks whether the metadata is *true*.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

from citation_engine import TYPE_LABELS, current_year, has_non_latin, normalize

_DOI_RE = re.compile(r"^10\.\d{4,9}/\S+$")


def _check_year(value: str, label: str, errors: list, warnings: list):
    if not value:
        return None
    if not re.fullmatch(r"\d{4}", value):
        errors.append(f"{label} must be a 4-digit year (for example 2023).")
        return None
    year = int(value)
    if year > current_year() + 1:
        errors.append(f"{label} {year} is in the future "
                      f"(latest accepted: {current_year() + 1}).")
        return None
    if year < 1800:
        warnings.append(f"{label} {year} is earlier than 1800 - please verify.")
    return year


def validate_source(data: dict) -> tuple[list[str], list[str]]:
    """Return (errors, warnings) for a raw form dictionary."""
    errors: list[str] = []
    warnings: list[str] = []
    raw_type = " ".join(str(data.get("source_type") or "").split())
    if raw_type not in TYPE_LABELS:
        errors.append("Please choose a valid source type.")
    r = normalize(data)
    t = r.source_type

    # ---- title / core fields ------------------------------------------
    if not r.title and not r.original_title:
        errors.append("A title is required: enter the published/translated "
                      "title, the original-language title, or both.")
    if not r.author:
        warnings.append("Author/creator is blank, so the reference will start "
                        "with the title. Check whether an organisation or "
                        "editor should be named instead.")

    year = _check_year(r.year, "Publication year", errors, warnings)
    if not r.year:
        warnings.append("Publication year is blank; APA will print “n.d.”. "
                        "Check what your style requires.")
    orig_year = _check_year(r.original_year, "Original publication year",
                            errors, warnings)
    if year and orig_year and orig_year > year:
        warnings.append("Original publication year is later than the "
                        "publication year of the version you used.")

    # ---- links ----------------------------------------------------------
    if r.url:
        parsed = urlparse(r.url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            errors.append("URL must be a full web address starting with "
                          "http:// or https://.")
    if r.doi:
        doi = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", r.doi, flags=re.I)
        if not _DOI_RE.match(doi):
            warnings.append("The DOI does not look like 10.xxxx/xxxxx - please check it.")

    # ---- type-specific completeness -------------------------------------
    if t == "journal":
        if not r.journal:
            warnings.append("Journal name is missing.")
        if not r.volume:
            warnings.append("Volume is missing (ignore if the journal has none).")
        if not r.pages:
            warnings.append("Page range or article number is missing, if applicable.")
    elif t == "book":
        if not r.publisher:
            warnings.append("Publisher is missing.")
    elif t == "web":
        if not r.url:
            warnings.append("URL is missing for the web source.")
        elif not r.access_date:
            warnings.append("No access date entered. Some styles ask for one "
                            "when content may change.")
    elif t == "report":
        if not r.publisher:
            warnings.append("Issuing department / organisation is missing.")
        if not r.identifier:
            warnings.append("Report / order number is blank; add it if the "
                            "report has one (helps readers find the source).")
        if not r.country:
            warnings.append("Country of publication is blank.")
    elif t == "patent":
        if not r.identifier:
            errors.append("A patent number is required for a patent citation.")
        if not r.publisher:
            warnings.append("Patent office / granting authority is missing.")
        if not r.country:
            warnings.append("Country is blank; it is part of the patent "
                            "identifier in IEEE and MLA.")

    # ---- multilingual / translation checks -------------------------------
    if r.original_title and not r.language:
        warnings.append("An original-language title was entered but the "
                        "language is blank. Name the language so readers know "
                        "what they are citing.")
    if r.non_english_original:
        if not r.original_title:
            warnings.append("This is a non-English source; record the "
                            "original-language title if available.")
        elif not r.title:
            warnings.append("No English translation of the title was entered, "
                            "so the bracketed translation is omitted.")
        if has_non_latin(r.original_title) and not r.transliteration:
            warnings.append("The original title is in a non-Latin script. A "
                            "Latin transliteration is optional but helps "
                            "readers who cannot read the script.")
    if r.title_display == "translit" and not r.transliteration:
        warnings.append("“Transliteration” title display was chosen but no "
                        "transliteration was entered; the native title is used.")
    if r.translator:
        if not r.original_title:
            warnings.append("A translator is named but the original title is "
                            "blank. Check the source record and style guidance.")
        if not r.original_year:
            warnings.append("A translator is named: add the original "
                            "publication year (APA prints “Original work "
                            "published …”).")
        if not r.language:
            warnings.append("A translator is named but the original language "
                            "is blank.")
    return errors, warnings
