# GeneSelect — Simple Version

A beginner-friendly, single-page Streamlit application for Genetic Algorithm (GA) feature selection and Random Forest classification.

## What the application does

1. Load a dataset by uploading a CSV, using the included synthetic sample, or downloading GSE10072 from NCBI GEO.
2. Show the sample count, number of numeric gene-expression features, and class distribution.
3. Train a Random Forest using the candidate features.
4. Use a Genetic Algorithm to search for a smaller feature subset.
5. Compare the baseline and GA-selected Random Forest results on a held-out test set.
6. Display selected features and a confusion matrix.

## Dataset format for CSV uploads

- One row = one sample.
- Numeric columns = gene/probe expression measurements.
- One column = class label, such as `Normal` or `Tumour`.
- At least 20 samples, two classes, and at least four samples in each class.

The included `data/sample_demo.csv` is synthetic data for testing the interface. It is not real patient or genomic data.

## Run on Windows

Open this folder in VS Code. In the terminal:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the local URL shown in the terminal, usually `http://localhost:8501`.

If you already have a working `.venv`, activate it and run:

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Simple explanation for viva

- **Dataset:** contains samples and their gene-expression values.
- **Feature:** one measured gene/probe column.
- **Target/class:** the known category for each sample (for example, Normal or Tumour).
- **Random Forest:** a machine-learning classifier that combines multiple decision trees.
- **Genetic Algorithm:** searches for a useful subset of features using selection, crossover and mutation.
- **Fitness:** cross-validation balanced accuracy with a small penalty for selecting too many features.
- **Comparison:** the same train/test split is used to compare Random Forest before and after GA feature selection.

## Important notes

- The application is an educational research prototype, not a clinical diagnostic tool.
- GSE10072 label parsing is based on GEO sample titles and should be checked against the original metadata.
- GEO feature identifiers can be probe IDs, not gene symbols. Use the correct platform annotation before making biological claims.
- The GA uses fixed beginner-friendly settings in the interface to keep operation simple.
