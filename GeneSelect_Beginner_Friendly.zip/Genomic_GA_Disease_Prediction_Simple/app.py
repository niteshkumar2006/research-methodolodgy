import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from pipeline import prepare_uploaded_data, run_ga_experiment
from geo_loader import download_geo_series_matrix, parse_geo_series_matrix

st.set_page_config(page_title="GeneSelect", page_icon="🧬", layout="centered")

st.title("🧬 GeneSelect")
st.subheader("Genetic Algorithm-Based Gene Selection for Disease Prediction")
st.write(
    "This project uses a Genetic Algorithm to select useful gene-expression "
    "features and a Random Forest model to classify samples."
)
st.info(
    "**Simple workflow:** Load dataset → Check dataset → Run feature selection → View results."
)

if "dataset" not in st.session_state:
    st.session_state.dataset = None
if "result" not in st.session_state:
    st.session_state.result = None

st.header("1. Load dataset")
st.write("Choose one dataset source. For a quick demonstration, use the sample CSV.")

source = st.radio(
    "Dataset source",
    ["Upload CSV file", "Use sample demonstration dataset", "Load public GSE10072 dataset"],
    horizontal=False,
)

if source == "Upload CSV file":
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"], key="csv_upload")
    if uploaded is not None:
        try:
            frame = pd.read_csv(uploaded)
            st.write("CSV preview")
            st.dataframe(frame.head(), use_container_width=True)
            target_col = st.selectbox("Which column contains the class labels?", frame.columns)
            if st.button("Load this dataset", type="primary"):
                X, y = prepare_uploaded_data(frame, target_col)
                st.session_state.dataset = {
                    "X": X, "y": y, "name": uploaded.name,
                    "source": f"Uploaded CSV; target column: {target_col}"
                }
                st.session_state.result = None
                st.success("Dataset loaded.")
        except Exception as exc:
            st.error(f"Could not read this CSV: {exc}")

elif source == "Use sample demonstration dataset":
    st.caption("This is synthetic data created for testing the interface. It is not real patient data.")
    if st.button("Load sample dataset", type="primary"):
        sample_path = ROOT / "data" / "sample_demo.csv"
        frame = pd.read_csv(sample_path)
        X, y = prepare_uploaded_data(frame, "Class")
        st.session_state.dataset = {
            "X": X, "y": y, "name": "Sample demonstration dataset",
            "source": "Synthetic sample data included with the project"
        }
        st.session_state.result = None
        st.success("Sample dataset loaded.")

else:
    st.caption("Downloads the processed expression matrix from NCBI GEO. Internet access is required.")
    if st.button("Download and load GSE10072", type="primary"):
        try:
            with st.spinner("Downloading and preparing the GEO dataset..."):
                matrix_path = download_geo_series_matrix("GSE10072", ROOT / "data")
                X, y, metadata = parse_geo_series_matrix(matrix_path, "GSE10072")
            st.session_state.dataset = {
                "X": X, "y": y, "name": "GSE10072",
                "source": "NCBI Gene Expression Omnibus (GEO)",
                "metadata": metadata
            }
            st.session_state.result = None
            st.success("GSE10072 loaded.")
        except Exception as exc:
            st.error(f"Could not load GSE10072: {exc}")
            st.caption("You can use the sample CSV or upload another labelled dataset instead.")

dataset = st.session_state.dataset

if dataset is not None:
    st.divider()
    st.header("2. Dataset overview")
    X, y = dataset["X"], dataset["y"]
    a, b, c = st.columns(3)
    a.metric("Samples", f"{X.shape[0]:,}")
    b.metric("Gene features", f"{X.shape[1]:,}")
    c.metric("Classes", f"{y.nunique():,}")
    st.write("Class distribution")
    st.bar_chart(y.value_counts().rename_axis("Class").to_frame("Samples"))
    with st.expander("Preview first five samples"):
        st.dataframe(X.head(), use_container_width=True)
    st.caption(f"Dataset: {dataset['name']} · Source: {dataset['source']}")
    if "metadata" in dataset:
        st.caption("GEO features may be probe IDs rather than confirmed gene symbols.")

    st.divider()
    st.header("3. Run feature selection")
    st.write(
        "Click the button below. The application trains a baseline Random Forest, "
        "uses the Genetic Algorithm to search for a smaller feature set, and tests "
        "the selected features using the same held-out test samples."
    )
    st.caption(
        "For a beginner-friendly run, the algorithm uses fixed settings: "
        "8 candidate solutions, 3 generations and 100 Random Forest trees."
    )
    if st.button("Run Genetic Algorithm", type="primary", use_container_width=True):
        try:
            with st.spinner("Running feature selection and training the models. Please wait..."):
                result = run_ga_experiment(
                    X, y,
                    test_size=0.25,
                    max_candidates=300,
                    population_size=8,
                    generations=3,
                    mutation_probability=0.08,
                    feature_penalty=0.02,
                    n_estimators=100,
                    random_state=42,
                )
            st.session_state.result = result
            st.success("Feature selection completed.")
        except Exception as exc:
            st.error(f"Could not complete the experiment: {exc}")
            st.exception(exc)

if st.session_state.result is not None:
    result = st.session_state.result
    st.divider()
    st.header("4. Results")
    baseline = result["baseline_metrics"]
    optimized = result["optimized_metrics"]

    st.write("**Model performance comparison**")
    comparison = pd.DataFrame(
        {
            "Before feature selection": {
                "Accuracy": baseline["accuracy"],
                "Balanced accuracy": baseline["balanced_accuracy"],
                "F1 score": baseline["f1_macro"],
            },
            "After GA feature selection": {
                "Accuracy": optimized["accuracy"],
                "Balanced accuracy": optimized["balanced_accuracy"],
                "F1 score": optimized["f1_macro"],
            },
        }
    )
    st.dataframe(comparison.round(3), use_container_width=True)

    left, right = st.columns(2)
    left.metric("Features before selection", result["candidate_count"])
    right.metric("Features selected by GA", len(result["selected_features"]))

    st.write("**Selected gene-expression features**")
    selected = pd.DataFrame(
        {
            "Feature": result["selected_features"],
            "Importance": result["selected_importances"],
        }
    ).sort_values("Importance", ascending=False)
    st.dataframe(selected, use_container_width=True, hide_index=True)

    st.write("**Confusion matrix (GA + Random Forest)**")
    matrix = pd.DataFrame(
        result["confusion_matrix"],
        index=[f"Actual {name}" for name in result["class_names"]],
        columns=[f"Predicted {name}" for name in result["class_names"]],
    )
    st.dataframe(matrix, use_container_width=True)

    st.download_button(
        "Download selected features",
        selected.to_csv(index=False),
        file_name="selected_features.csv",
        mime="text/csv",
    )

    st.warning(
        "Research/education prototype only. It is not a medical diagnostic tool. "
        "For GSE10072, selected probe IDs must be mapped with the correct platform "
        "annotation before describing them as gene biomarkers."
    )

st.divider()
st.caption("GeneSelect | Genetic Algorithm + Random Forest | Educational research prototype")
