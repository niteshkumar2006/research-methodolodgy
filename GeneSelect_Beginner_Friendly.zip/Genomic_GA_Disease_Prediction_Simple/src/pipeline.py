import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report, confusion_matrix

def prepare_uploaded_data(frame: pd.DataFrame, target: str):
    if target not in frame.columns: raise ValueError('Target column not found.')
    y=frame[target].astype(str).str.strip()
    X=frame.drop(columns=[target]).copy().apply(pd.to_numeric,errors='coerce')
    X=X.replace([np.inf,-np.inf],np.nan).dropna(axis=1,how='all')
    if X.shape[0]<20: raise ValueError('Please provide at least 20 labelled samples.')
    if y.nunique()<2: raise ValueError('The target must contain at least two classes.')
    if y.value_counts().min()<4: raise ValueError('Each class must contain at least four samples.')
    X.columns=X.columns.astype(str)
    return X,y

def _metrics(y_true,pred,prob,n_classes):
    result={'accuracy':accuracy_score(y_true,pred),'balanced_accuracy':balanced_accuracy_score(y_true,pred),'precision_macro':precision_score(y_true,pred,average='macro',zero_division=0),'recall_macro':recall_score(y_true,pred,average='macro',zero_division=0),'f1_macro':f1_score(y_true,pred,average='macro',zero_division=0),'roc_auc':np.nan}
    try:
        result['roc_auc']=roc_auc_score(y_true,prob[:,1]) if n_classes==2 else roc_auc_score(y_true,prob,multi_class='ovr',average='macro')
    except Exception: pass
    return result

def run_ga_experiment(X,y,test_size=.25,max_candidates=300,population_size=10,generations=5,mutation_probability=.08,feature_penalty=.02,n_estimators=150,random_state=42):
    X=X.copy(); X.columns=X.columns.astype(str); y=pd.Series(y).astype(str).reset_index(drop=True); X=X.reset_index(drop=True)
    if X.shape[0]<20 or y.nunique()<2: raise ValueError('Dataset must have at least 20 samples and two classes.')
    if y.value_counts().min()<4: raise ValueError('Each class needs at least four samples for stratified train/test and cross-validation.')
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=test_size,stratify=y,random_state=random_state)
    imputer=SimpleImputer(strategy='median',keep_empty_features=True)
    train=imputer.fit_transform(X_train); test=imputer.transform(X_test)
    train=np.nan_to_num(train,nan=0.,posinf=0.,neginf=0.); test=np.nan_to_num(test,nan=0.,posinf=0.,neginf=0.)
    variances=np.var(train,axis=0); valid=np.flatnonzero(variances>1e-12)
    if not len(valid): raise ValueError('No variable features remain after preprocessing.')
    ranked=valid[np.argsort(variances[valid])[::-1]]; candidate_idx=ranked[:min(int(max_candidates),len(ranked))]
    Xtr=train[:,candidate_idx]; Xte=test[:,candidate_idx]; candidate_names=np.asarray(X.columns)[candidate_idx]
    encoder=LabelEncoder(); ytr=encoder.fit_transform(y_train); yte=encoder.transform(y_test); n_classes=len(encoder.classes_)
    folds=min(3,int(pd.Series(ytr).value_counts().min()))
    if folds<2: raise ValueError('Not enough training examples per class for cross-validation.')
    cv=StratifiedKFold(n_splits=folds,shuffle=True,random_state=random_state)
    def model(seed): return RandomForestClassifier(n_estimators=int(n_estimators),class_weight='balanced',max_features='sqrt',n_jobs=-1,random_state=seed)
    baseline=model(random_state); baseline.fit(Xtr,ytr)
    baseline_metrics=_metrics(yte,baseline.predict(Xte),baseline.predict_proba(Xte),n_classes)
    rng=np.random.default_rng(random_state); n_features=Xtr.shape[1]; cache={}
    def fitness(chrom):
        selected=tuple(np.flatnonzero(chrom).tolist())
        if not selected: return 0.
        if selected not in cache:
            score=cross_val_score(model(random_state),Xtr[:,selected],ytr,cv=cv,scoring='balanced_accuracy',n_jobs=1).mean()
            cache[selected]=float(score-feature_penalty*(len(selected)/n_features))
        return cache[selected]
    upper=max(2,min(n_features,max(4,int(n_features*.2))+1))
    lower=max(1,min(3,n_features))
    population=[]
    for _ in range(population_size):
        count=int(rng.integers(lower,upper)) if upper>lower else lower
        chrom=np.zeros(n_features,dtype=np.uint8); chrom[rng.choice(n_features,size=min(count,n_features),replace=False)]=1; population.append(chrom)
    history=[]; best_chrom=None; best_score=-1e9
    def tournament(pop,fits):
        choices=rng.choice(len(pop),size=min(3,len(pop)),replace=False)
        return pop[max(choices,key=lambda i:fits[i])].copy()
    for gen in range(generations+1):
        fits=[fitness(ind) for ind in population]; winner=int(np.argmax(fits))
        if fits[winner]>best_score: best_score=fits[winner]; best_chrom=population[winner].copy()
        history.append({'generation':gen,'best_fitness':float(max(fits)),'mean_fitness':float(np.mean(fits)),'best_feature_count':int(best_chrom.sum())})
        if gen==generations: break
        next_pop=[best_chrom.copy()]
        while len(next_pop)<population_size:
            p1=tournament(population,fits); p2=tournament(population,fits); c1=p1.copy(); c2=p2.copy()
            if n_features>1 and rng.random()<.85:
                point=int(rng.integers(1,n_features)); c1=np.r_[p1[:point],p2[point:]]; c2=np.r_[p2[:point],p1[point:]]
            for child in (c1,c2):
                mask=rng.random(n_features)<mutation_probability; child[mask]=1-child[mask]
                if not child.any(): child[int(rng.integers(0,n_features))]=1
                next_pop.append(child)
                if len(next_pop)>=population_size: break
        population=next_pop
    selected_idx=np.flatnonzero(best_chrom)
    optimized=model(random_state); optimized.fit(Xtr[:,selected_idx],ytr)
    opt_pred=optimized.predict(Xte[:,selected_idx]); opt_prob=optimized.predict_proba(Xte[:,selected_idx])
    optimized_metrics=_metrics(yte,opt_pred,opt_prob,n_classes)
    return {'baseline_metrics':baseline_metrics,'optimized_metrics':optimized_metrics,'selected_features':candidate_names[selected_idx].tolist(),'selected_importances':optimized.feature_importances_.tolist(),'candidate_count':len(candidate_names),'history':history,'classification_report':classification_report(yte,opt_pred,target_names=encoder.classes_,output_dict=True,zero_division=0),'confusion_matrix':confusion_matrix(yte,opt_pred).tolist(),'class_names':encoder.classes_.tolist(),'model':optimized,'imputer':imputer,'candidate_columns':candidate_names.tolist(),'selected_indices':selected_idx.tolist(),'original_columns':X.columns.tolist(),'encoder':encoder}

def predict_samples(result,frame):
    if frame is None or frame.empty: raise ValueError('Upload a non-empty CSV.')
    original=result['original_columns']; missing=[c for c in original if c not in frame.columns]
    if missing: raise ValueError(f'Prediction file is missing original input columns, e.g. {missing[:8]}')
    aligned=frame[original].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
    arr=result['imputer'].transform(aligned); arr=np.nan_to_num(arr,nan=0.,posinf=0.,neginf=0.)
    candidate_positions=[original.index(c) for c in result['candidate_columns']]
    selected_positions=[candidate_positions[i] for i in result['selected_indices']]
    selected=arr[:,selected_positions]; pred=result['model'].predict(selected); probs=result['model'].predict_proba(selected)
    out=pd.DataFrame({'Predicted class':result['encoder'].inverse_transform(pred)})
    for j,label in enumerate(result['encoder'].classes_): out[f'Probability: {label}']=probs[:,j]
    return out
