from pathlib import Path
from io import StringIO
import gzip
import urllib.request
import pandas as pd
import numpy as np

GEO_DATASETS = {
    'GSE10072': {
        'label': 'GSE10072 — Lung adenocarcinoma vs normal lung',
        'description': 'Public processed human lung tissue microarray series from NCBI GEO. The app identifies tumour and normal samples from sample titles.',
        'prefix': 'GSE10nnn'
    }
}

def download_geo_series_matrix(accession: str, data_dir: Path) -> Path:
    if accession not in GEO_DATASETS:
        raise ValueError('Unsupported GEO accession.')
    data_dir.mkdir(parents=True, exist_ok=True)
    filename = f'{accession}_series_matrix.txt.gz'
    destination = data_dir / filename
    if destination.exists() and destination.stat().st_size > 1000:
        return destination
    url = f"https://ftp.ncbi.nlm.nih.gov/geo/series/{GEO_DATASETS[accession]['prefix']}/{accession}/matrix/{filename}"
    request = urllib.request.Request(url, headers={'User-Agent':'GeneSelect educational research application'})
    try:
        with urllib.request.urlopen(request, timeout=120) as response, open(destination,'wb') as output:
            while True:
                chunk=response.read(1024*1024)
                if not chunk: break
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    if destination.stat().st_size < 1000:
        destination.unlink(missing_ok=True)
        raise ValueError('The downloaded GEO file is unexpectedly small.')
    return destination

def parse_geo_series_matrix(path: Path, accession='GSE10072'):
    with gzip.open(path,'rt',encoding='utf-8',errors='replace') as f:
        lines=f.readlines()
    titles=None; table_start=None; table_end=None
    for i,line in enumerate(lines):
        if line.startswith('!Sample_title'):
            titles=line.rstrip('\r\n').split('\t')[1:]
        elif line.startswith('!series_matrix_table_begin'):
            table_start=i+1
        elif line.startswith('!series_matrix_table_end'):
            table_end=i; break
    if titles is None or table_start is None or table_end is None:
        raise ValueError('GEO Series Matrix is missing sample titles or the expression table.')
    raw=pd.read_csv(StringIO(''.join(lines[table_start:table_end])),sep='\t',index_col=0,low_memory=False)
    raw=raw.apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
    raw=raw.dropna(axis=0,how='all').dropna(axis=1,how='all')
    if len(titles)!=raw.shape[1]:
        raise ValueError(f'Sample metadata count ({len(titles)}) differs from expression columns ({raw.shape[1]}).')
    keep=[]; labels=[]; unmatched=[]
    for col,title in zip(raw.columns,titles):
        t=str(title).lower()
        # Keep only unambiguous tumour/normal descriptors; exclude other sample types.
        if any(term in t for term in ['normal lung','normal tissue','non-tumor','non-tumour','non tumor','non tumour']):
            keep.append(col); labels.append('Normal')
        elif any(term in t for term in ['tumor','tumour','adenocarcinoma','cancer']):
            keep.append(col); labels.append('Tumour')
        else:
            unmatched.append(str(title))
    if len(keep)<20 or len(set(labels))<2:
        raise ValueError('Could not confidently infer both tumour and normal labels from sample titles. Use the labelled CSV upload option instead. Unmatched titles: '+ '; '.join(unmatched[:8]))
    # Expression table rows are probes and columns are samples; transpose for ML.
    X=raw.loc[:,keep].T.copy()
    X.index=[str(v) for v in X.index]
    X.columns=[str(v) for v in X.columns]
    X=X.apply(pd.to_numeric,errors='coerce')
    X=X.replace([np.inf,-np.inf],np.nan)
    X=X.loc[:,X.notna().any(axis=0)]
    y=pd.Series(labels,index=X.index,name='Class')
    meta={'source':'NCBI Gene Expression Omnibus','accession':accession,'platform_note':'GSE10072 is commonly associated with Affymetrix GPL96; verify the GEO record/platform annotation.','label_rule':'Sample title keyword-based tumour/normal parsing; inspect labels before interpreting results.','unmatched_sample_titles':unmatched[:20],'note':'Features are probe IDs, not validated gene symbols. Map using the matching GEO platform annotation.'}
    return X,y,meta
