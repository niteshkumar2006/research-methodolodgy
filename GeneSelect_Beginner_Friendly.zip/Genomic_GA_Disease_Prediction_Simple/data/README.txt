sample_demo.csv is synthetic demonstration data for testing the GeneSelect interface. It is not a real genomic dataset or patient data.
